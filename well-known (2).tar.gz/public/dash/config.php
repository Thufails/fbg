<?php
// config.php - Konfigurasi database
$host = '72.60.77.1';
$dbname = 'binsysid_sbs';
$username = 'n8n_user';
$password = 'StrongPassword123!';

try {
    $pdo = new PDO("mysql:host=$host;dbname=$dbname;charset=utf8", $username, $password);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
} catch (PDOException $e) {
    die("Koneksi database gagal: " . $e->getMessage());
}
?>