@extends('layouts.app')
@section('title', 'Daftar Target Detail')
@section('content')
<div class="container-fluid">
  <h4 class="mb-3"><i class="bi bi-search"></i> Data Target Detail</h4>
  
  <!-- Search Form -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form action="{{ route('detailTarget.view') }}" method="GET" class="mb-0">
        @csrf
        <div class="row g-3 align-items-end">
          <div class="col-md-4">
            <label for="start_date" class="form-label">Tanggal Awal</label>
            <input type="date" name="start_date" class="form-control" 
                   value="{{ request('start_date') }}" id="start_date">
          </div>
          <div class="col-md-4">
            <label for="end_date" class="form-label">Tanggal Akhir</label>
            <input type="date" name="end_date" class="form-control" 
                   value="{{ request('end_date') }}" id="end_date">
          </div>
          <div class="col-md-3">
            <label for="kd_detail_akun" class="form-label">Detail Akun</label>
            <select name="kd_detail_akun" class="form-select" id="kd_detail_akun">
              <option value="">Semua Detail Akun</option>
              @foreach($detailAkunList ?? [] as $detailAkun)
                <option value="{{ $detailAkun->kd_detail_akun }}" {{ request('kd_detail_akun') == $detailAkun->kd_detail_akun ? 'selected' : '' }}>
                  {{ $detailAkun->kd_detail_akun }} - {{ $detailAkun->nama_akun }} - {{ $detailAkun->nama_detail_akun }}
                </option>
              @endforeach
            </select>
          </div>
          <div class="col-md-1">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-funnel me-1"></i> Filter
            </button>
            @if(request('start_date') || request('end_date') || request('kd_detail_akun'))
            <a href="{{ route('detailTarget.view') }}" class="btn btn-secondary w-100 mt-2">
              <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
            </a>
            @endif
          </div>
        </div>
      </form>
    </div>
  </div>

  <div class="d-flex justify-content-between align-items-center mb-3">
    <div class="text-muted">
      Menampilkan {{ $detailTarget->firstItem() ?? 0 }} - {{ $detailTarget->lastItem() ?? 0 }} dari {{ $detailTarget->total() ?? 0 }} Target Detail
    </div>
    <div>
      <button id="bulkDeleteBtn" class="btn btn-danger me-2" disabled>
        <i class="bi bi-trash me-1"></i> Hapus yang Dipilih
      </button>
      <button id="bulkUpdateBtn" class="btn btn-primary me-2" disabled>
        <i class="bi bi-pencil-square me-1"></i> Update yang Dipilih
      </button>
      <a href="{{ route('detailTarget.select') }}" class="btn btn-success">
        <i class="bi bi-plus-circle me-1"></i> Tambah Target Detail
      </a>
    </div>
  </div>

  <!-- Data Table -->
  <div class="table-responsive">
    <form id="bulkDeleteForm" action="{{ route('detailTarget.bulkDestroy') }}" method="POST">
      @csrf
      @method('DELETE')
      <table class="table table-bordered table-hover align-middle">
        <thead class="table-dark text-center">
          <tr>
            <th width="50">
              <input type="checkbox" id="checkAll" class="form-check-input">
            </th>
            <th width="60">No</th>
            <th>Tanggal</th>
            <th>Akun</th>
            <th>Detail Akun</th>
            <th>Nilai Target</th>
          </tr>
        </thead>
        <tbody>
          @forelse ($detailTarget as $item)
          <tr>
            <td class="text-center">
              <input type="checkbox" name="selected_ids[]" value="{{ $item->kd_target_detail }}" class="form-check-input target-checkbox">
            </td>
            <td class="text-center">{{ ($detailTarget->currentPage() - 1) * $detailTarget->perPage() + $loop->iteration }}</td>
            <td>{{ \Carbon\Carbon::parse($item->tanggal)->format('d-m-Y') }}</td>
            <td>{{ $item->nama_akun }}</td>
            <td>{{ $item->nama_detail_akun ?? '-' }}</td>
            <td class="text-end">{{ number_format($item->nilai, 0, ',', '.') }}</td>
          </tr>
          @empty
          <tr>
            <td colspan="7" class="text-center py-4">
              @if(request('start_date') || request('end_date') || request('kd_detail_akun'))
                Tidak ditemukan target detail dengan filter yang dipilih
              @else
                Tidak ada data target detail
              @endif
            </td>
          </tr>
          @endforelse
        </tbody>
      </table>
    </form>
  </div>

  <!-- Pagination -->
  @if($detailTarget->hasPages())
  <div class="d-flex justify-content-center mt-4">
    {{ $detailTarget->withQueryString()->links() }}
  </div>
  @endif
</div>

<!-- Bulk Update Modal -->
<div class="modal fade" id="bulkUpdateModal" tabindex="-1" aria-labelledby="bulkUpdateModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <form id="bulkUpdateForm" action="{{ route('detailTarget.bulkUpdate') }}" method="POST">
        @csrf
        <div class="modal-header">
          <h5 class="modal-title" id="bulkUpdateModalLabel">Update Detail Target Terpilih</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          <div class="mb-3">
            <label for="update_nilai" class="form-label">Nilai Target</label>
            <input type="text" class="form-control" id="update_nilai" name="nilai" placeholder="Masukkan nilai target" required>
            <input type="hidden" name="nilai_raw" id="update_nilai_raw">
          </div>
          <input type="hidden" name="selected_ids" id="selected_ids_input">
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <button type="submit" class="btn btn-primary">
            <span id="updateButtonText">Update</span>
            <span id="updateSpinner" class="spinner-border spinner-border-sm d-none" role="status" aria-hidden="true"></span>
          </button>
        </div>
      </form>
    </div>
  </div>
</div>

<style>
  .table {
    font-size: 0.9rem;
  }
  .table-dark {
    background-color: #212529;
  }
  .table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.05);
  }
  .btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.75rem;
  }
  .card {
    border-radius: 0.5rem;
    border: 1px solid #dee2e6;
  }
  .text-end {
    text-align: right !important;
  }
  .form-check-input {
    cursor: pointer;
    margin: 0 auto;
    display: block;
  }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Elements
  const checkAll = document.getElementById('checkAll');
  const checkboxes = document.querySelectorAll('.target-checkbox');
  const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
  const bulkUpdateBtn = document.getElementById('bulkUpdateBtn');
  const bulkDeleteForm = document.getElementById('bulkDeleteForm');
  const bulkUpdateModal = new bootstrap.Modal(document.getElementById('bulkUpdateModal'));
  const bulkUpdateForm = document.getElementById('bulkUpdateForm');
  const selectedIdsInput = document.getElementById('selected_ids_input');
  const updateSpinner = document.getElementById('updateSpinner');
  const updateButtonText = document.getElementById('updateButtonText');
  const updateNilaiInput = document.getElementById('update_nilai');
  const updateNilaiRaw = document.getElementById('update_nilai_raw');

  // Check All functionality
  checkAll.addEventListener('change', function() {
    const isChecked = this.checked;
    checkboxes.forEach(checkbox => {
      checkbox.checked = isChecked;
    });
    updateBulkActionButtons();
  });

  // Individual checkbox functionality
  checkboxes.forEach(checkbox => {
    checkbox.addEventListener('change', function() {
      if (!this.checked && checkAll.checked) {
        checkAll.checked = false;
      }
      const allChecked = Array.from(checkboxes).every(cb => cb.checked);
      checkAll.checked = allChecked;
      updateBulkActionButtons();
    });
  });

  // Update bulk action buttons state
  function updateBulkActionButtons() {
    const checkedCount = document.querySelectorAll('.target-checkbox:checked').length;
    bulkDeleteBtn.disabled = checkedCount === 0;
    bulkUpdateBtn.disabled = checkedCount === 0;
    
    bulkDeleteBtn.innerHTML = checkedCount > 0 
      ? `<i class="bi bi-trash me-1"></i> Hapus (${checkedCount})` 
      : `<i class="bi bi-trash me-1"></i> Hapus yang Dipilih`;
      
    bulkUpdateBtn.innerHTML = checkedCount > 0 
      ? `<i class="bi bi-pencil-square me-1"></i> Update (${checkedCount})` 
      : `<i class="bi bi-pencil-square me-1"></i> Update yang Dipilih`;
  }

  // Bulk delete button click handler
  bulkDeleteBtn.addEventListener('click', function(e) {
    e.preventDefault();
    const checkedCount = document.querySelectorAll('.target-checkbox:checked').length;
    
    if (checkedCount > 0 && confirm(`Apakah Anda yakin ingin menghapus ${checkedCount} detail target yang dipilih?`)) {
      // Show loading state
      bulkDeleteBtn.disabled = true;
      bulkDeleteBtn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Menghapus...`;
      
      // Submit form
      bulkDeleteForm.submit();
    }
  });

  // Bulk update button click handler
  bulkUpdateBtn.addEventListener('click', function() {
    const checkedCheckboxes = document.querySelectorAll('.target-checkbox:checked');
    const selectedIds = Array.from(checkedCheckboxes).map(cb => cb.value);
    
    // Set selected IDs in hidden input
    selectedIdsInput.value = JSON.stringify(selectedIds);
    
    // Reset form
    updateNilaiInput.value = '';
    updateNilaiRaw.value = '';
    
    // Show modal
    bulkUpdateModal.show();
  });

  // Format nilai input
  updateNilaiInput.addEventListener('keyup', function() {
    let rawValue = this.value.replace(/[^0-9]/g, '');
    updateNilaiRaw.value = rawValue;
    if (rawValue) {
      this.value = parseInt(rawValue).toLocaleString('id-ID');
    } else {
      this.value = '';
    }
  });

  // Bulk update form submission
  bulkUpdateForm.addEventListener('submit', function(e) {
    // Validate nilai input
    if (!updateNilaiRaw.value) {
      e.preventDefault();
      alert('Silakan masukkan nilai target');
      return;
    }
    
    // Show loading state
    updateSpinner.classList.remove('d-none');
    updateButtonText.textContent = 'Memproses...';
    bulkUpdateForm.querySelector('button[type="submit"]').disabled = true;
  });
});
</script>
@endsection