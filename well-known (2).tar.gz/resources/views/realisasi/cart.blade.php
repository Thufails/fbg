@extends('layouts.app')
@section('title', 'Keranjang Realisasi')
@section('content')
<div class="container-fluid">
    <h4 class="mb-3"><i class="bi bi-cart"></i> Keranjang Realisasi</h4>
    <div class="card mb-4">
        <div class="card-body">
            @if(empty($cartItems))
                <div class="alert alert-warning">Keranjang realisasi Anda kosong.</div>
            @else
                <div class="d-flex justify-content-between mb-3">
                    <div>
                        <h5>Akun: {{ $akunInfo->kd_akun ?? '' }} - {{ $akunInfo->nama_akun ?? '' }}</h5>
                    </div>
                    <div>
                        <a href="{{ route('realisasi.emptyCart') }}" class="btn btn-danger me-2">
                            <i class="bi bi-trash me-1"></i> Kosongkan Keranjang
                        </a>
                        <a href="{{ route('realisasi.select') }}" class="btn btn-secondary">
                            <i class="bi bi-arrow-left me-1"></i> Kembali ke Pilih Target
                        </a>
                    </div>
                </div>
                
                <form action="{{ route('realisasi.store') }}" method="POST">
                    @csrf
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-dark">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Kode Akun</th>
                                    <th>Nilai Target</th>
                                    <th width="200">Nilai Realisasi</th>
                                    <th width="250">Keterangan</th>
                                    <th width="50">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                @foreach($cartItems as $index => $item)
                                <tr>
                                    <td>{{ \Carbon\Carbon::parse($item['tanggal'])->format('d-m-Y') }}</td>
                                    <td>{{ $item['kd_akun'] }}</td>
                                    <td class="text-end">{{ number_format($item['nilai_target'], 0, ',', '.') }}</td>
                                    <td>
                                        <input type="number" 
                                               name="realisasi[{{ $index }}][nilai]" 
                                               class="form-control" 
                                               value="{{ $item['nilai_realisasi'] }}" 
                                               required>
                                        <input type="hidden" 
                                               name="realisasi[{{ $index }}][kd_target]" 
                                               value="{{ $item['kd_target'] }}">
                                        <input type="hidden" 
                                               name="realisasi[{{ $index }}][tanggal]" 
                                               value="{{ $item['tanggal'] }}">
                                    </td>
                                    <td>
                                        <input type="text" 
                                               name="realisasi[{{ $index }}][keterangan]" 
                                               class="form-control" 
                                               value="{{ $item['keterangan'] }}">
                                    </td>
                                    <td class="text-center">
                                        <a href="{{ route('realisasi.removeFromCart', $index) }}" 
                                           class="btn btn-sm btn-danger"
                                           title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                @endforeach
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="d-flex justify-content-between mt-3">
                        <div class="text-muted">
                            Total Item: {{ count($cartItems) }}
                        </div>
                        <div>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-save me-1"></i> Simpan Realisasi
                            </button>
                        </div>
                    </div>
                </form>
            @endif
        </div>
    </div>
</div>
@endsection