
<?php $__env->startSection('content'); ?>
  <h3 class="mb-4"><i class="bi bi-pencil-square"></i> Edit Data Produk</h3>
  <form action="<?php echo e(route('produk.update', $produk->kd_produk)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?> <!-- Menyatakan bahwa ini adalah request PUT -->
    
    <div class="mb-3">
      <label class="form-label"><i class="bi bi-upc-scan"></i> Kode Produk</label>
      <input type="text" name="kd_produk" class="form-control" value="<?php echo e(old('kd_produk', $produk->kd_produk)); ?>" readonly>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-box"></i> Nama Produk</label>
      <input type="text" name="nama_produk" class="form-control" value="<?php echo e(old('nama_produk', $produk->nama_produk)); ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-cash-coin"></i> Harga</label>
      <input type="number" name="harga" class="form-control" value="<?php echo e(old('harga', $produk->harga)); ?>" required>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-card-text"></i> Keterangan</label>
      <textarea name="keterangan" class="form-control" rows="3"><?php echo e(old('keterangan', $produk->keterangan)); ?></textarea>
    </div>

    <div class="d-flex justify-content-between">
      <a href="<?php echo e(route('produk.view')); ?>" class="btn btn-secondary"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
      <button type="submit" class="btn btn-primary"><i class="bi bi-save2"></i> Simpan Perubahan</button>
    </div>

  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appform', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/produk/edit.blade.php ENDPATH**/ ?>