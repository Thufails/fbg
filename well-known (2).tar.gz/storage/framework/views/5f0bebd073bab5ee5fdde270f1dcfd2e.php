
<?php $__env->startSection('title','Tambah User'); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card p-4">
            <h1>Tambah User</h1>            
            <form action="<?php echo e(route('user.store')); ?>" method="post">
                <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo csrf_field(); ?>
                <div class="mb-2">
                    <label for="email" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="email" value="<?php echo e(old('email')); ?>" name="email" aria-describedby="emailHelp">
                </div>
                <div class="mb-2">
                    <label for="name" class="form-label">Nama</label>
                    <input type="text" class="form-control" id="name" value="<?php echo e(old('name')); ?>" name="name">
                </div>
                <div class="mb-2">
                    <label for="level" class="form-label">Level</label>
                    <select class="form-select" id="level" name="level">
                        <option value="" disabled selected>Pilih Level</option>
                        <option value="admin" <?php echo e(old('level') == 'admin' ? 'selected' : ''); ?>>Administrator</option>
                        <option value="user" <?php echo e(old('level') == 'user' ? 'selected' : ''); ?>>User</option>
                        <option value="analis" <?php echo e(old('level') == 'analis' ? 'selected' : ''); ?>>Analis</option>
                        <option value="guest" <?php echo e(old('level') == 'guest' ? 'selected' : ''); ?>>Guest</option>
                    </select>
                </div>
                <div class="mb-2">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" id="password">
                </div>
                <div class="mb-2">
                    <label for="password-confirmation" class="form-label">Konfirmasi Password</label>
                    <input type="password" class="form-control" name="password_confirmation" id="password_confirmation">
                </div>
                <div class="d-inline">
                    <button type="submit" class="btn btn-primary">Simpan</button>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/user/insert.blade.php ENDPATH**/ ?>