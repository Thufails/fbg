
<?php $__env->startSection('title','Master Produk'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <h4 class="mb-3"><i class="bi bi-box-seam"></i> Daftar Produk</h4>
  <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Form Pencarian dengan Card -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form action="<?php echo e(route('produk.view')); ?>" method="GET" class="mb-0">
        <div class="row g-3 align-items-end">
          <div class="col-md-8">
            <label for="search" class="form-label">Cari Produk</label>
            <div class="input-group">
              <input type="text" name="search" class="form-control" 
                     placeholder="Masukkan nama produk..." 
                     value="<?php echo e(request('search')); ?>"
                     id="searchInput">
              <button type="submit" class="btn btn-primary">
                <i class="bi bi-search me-1"></i> Cari
              </button>
              <?php if(request('search')): ?>
              <a href="<?php echo e(route('produk.view')); ?>" class="btn btn-secondary">
                <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
              </a>
              <?php endif; ?>
            </div>
          </div>
        </div>
      </form>
    </div>
  </div>

  <!-- Info Hasil Pencarian -->
  <?php if(request('search')): ?>
  <div class="alert alert-info mb-3">
    <i class="bi bi-info-circle"></i> Menampilkan hasil pencarian untuk: <strong>"<?php echo e(request('search')); ?>"</strong>
    <a href="<?php echo e(route('produk.view')); ?>" class="float-end text-decoration-none">
      <i class="bi bi-x"></i> Hapus pencarian
    </a>
  </div>
  <?php endif; ?>

  <!-- Baris Info Jumlah Data dan Tombol Tambah -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div class="text-muted">
      Menampilkan <?php echo e($produk->firstItem() ?? 0); ?> - <?php echo e($produk->lastItem() ?? 0); ?> dari <?php echo e($produk->total() ?? 0); ?> produk
    </div>
    <a href="<?php echo e(route('produk.insert')); ?>" class="btn btn-success">
      <i class="bi bi-plus-circle me-1"></i> Tambah Produk
    </a>
  </div>

  <div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
      <thead class="table-dark text-center">
        <tr>
          <th width="60">No</th>
          <th>Kode</th>
          <th>Nama</th>
          <th>Harga</th>
          <th>Keterangan</th>
          <th width="120">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $produk; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="text-center"><?php echo e(($produk->currentPage() - 1) * $produk->perPage() + $loop->iteration); ?></td>
          <td><?php echo e($item->kd_produk); ?></td>
          <td><?php echo e($item->nama_produk); ?></td>
          <td>Rp <?php echo e(number_format($item->harga, 0, ',', '.')); ?></td>
          <td><?php echo e($item->keterangan); ?></td>
          <td class="text-center">
            <a href="<?php echo e(route('produk.edit', $item->kd_produk)); ?>" class="btn btn-warning btn-sm" title="Edit">
              <i class="bi bi-pencil-square"></i>
            </a>
            <form action="<?php echo e(route('produk.destroy', $item->kd_produk)); ?>" method="POST" class="d-inline">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger btn-sm" 
                      onclick="return confirm('Apakah Anda yakin ingin menghapus produk ini?');" title="Hapus">
                <i class="bi bi-trash"></i>
              </button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="6" class="text-center py-4">
            <?php if(request('search')): ?>
              Produk dengan nama "<?php echo e(request('search')); ?>" tidak ditemukan
            <?php else: ?>
              Tidak ada data produk
            <?php endif; ?>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if($produk->hasPages()): ?>
  <div class="d-flex justify-content-center mt-4">
    <?php echo e($produk->withQueryString()->links()); ?>

  </div>
  <?php endif; ?>
</div>

<script>
// Auto focus ke input pencarian
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.focus();
        
        // Clear pencarian dengan tombol Esc
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Escape') {
                window.location.href = "<?php echo e(route('produk.view')); ?>";
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/produk/view.blade.php ENDPATH**/ ?>