
<?php $__env->startSection('title', 'Keranjang Penjualan'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h4 class="mb-3"><i class="bi bi-cart"></i> Keranjang Penjualan</h4>
    <div class="card mb-4">
        <div class="card-body">
            <?php if(empty($cart)): ?>
                <div class="alert alert-warning">Keranjang Anda kosong.</div>
            <?php else: ?>
                <!-- Form untuk menyimpan penjualan -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Simpan Penjualan</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('penjualan.storeCart')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label for="tanggal" class="form-label">Tanggal Penjualan</label>
                                    <input type="date" name="tanggal" id="tanggal" class="form-control" 
                                           value="<?php echo e(date('Y-m-d')); ?>" required>
                                </div>
                            </div>
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save"></i> Simpan Semua Penjualan
                                </button>
                                
                                <a href="<?php echo e(route('penjualan.emptyCart')); ?>" class="btn btn-danger">
                                    <i class="bi bi-trash"></i> Kosongkan Keranjang
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Tabel keranjang -->
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th width="50">No</th>
                                <th>Tanggal</th>
                                <th>Produk</th>
                                <th>Harga</th>
                                <th>Jumlah</th>
                                <th>Subtotal</th>
                                <th width="120">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cart; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($item['tanggal'])->format('d-m-Y')); ?></td>
                                <td><?php echo e($item['nama_produk']); ?></td>
                                <td class="text-end"><?php echo e(number_format($item['harga'], 0, ',', '.')); ?></td>
                                <td class="text-center"><?php echo e($item['jumlah']); ?></td>
                                <td class="text-end"><?php echo e(number_format($item['subtotal'], 0, ',', '.')); ?></td>
                                <td class="text-center">
                                    <form action="<?php echo e(route('penjualan.removeFromCart', $index)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="bi bi-trash"></i> Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <tr class="table-active">
                                <td colspan="5" class="text-end fw-bold">Total</td>
                                <td class="text-end fw-bold"><?php echo e(number_format(array_sum(array_column($cart, 'subtotal')), 0, ',', '.')); ?></td>
                                <td></td>
                            </tr>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
    
    <div class="d-flex justify-content-between">
        <a href="<?php echo e(route('penjualan.insert')); ?>" class="btn btn-success">
            <i class="bi bi-plus-circle"></i> Tambah Item Baru
        </a>
        <a href="<?php echo e(route('penjualan.view')); ?>" class="btn btn-secondary">
            <i class="bi bi-list"></i> Lihat Daftar Penjualan
        </a>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/penjualan/cart.blade.php ENDPATH**/ ?>