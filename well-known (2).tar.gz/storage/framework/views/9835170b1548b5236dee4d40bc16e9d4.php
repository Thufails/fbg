
<?php $__env->startSection('content'); ?>
    <div id="report-container">
        <?php include(public_path('dash/dashboard_final.php')); ?>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/dashboard/view.blade.php ENDPATH**/ ?>