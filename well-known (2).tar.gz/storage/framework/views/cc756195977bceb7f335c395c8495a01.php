
<?php $__env->startSection('content'); ?>
  <h3 class="mb-4"><i class="bi bi-eye"></i> Preview Konversi Tanggal</h3>
  
  <div class="card mb-4">
    <div class="card-header bg-info text-white">
      <i class="bi bi-info-circle"></i> Ringkasan Konversi
    </div>
    <div class="card-body">
      <div class="row">
        <div class="col-md-6">
          <table class="table table-sm">
            <tr>
              <th width="40%">Tanggal Masehi Awal:</th>
              <td><?php echo e(date('d-m-Y', strtotime($inputData['tanggal_awal']))); ?></td>
            </tr>
            <tr>
              <th>Tanggal Masehi Akhir:</th>
              <td><?php echo e(date('d-m-Y', strtotime($inputData['tanggal_akhir']))); ?></td>
            </tr>
            <tr>
              <th>Total Hari:</th>
              <td><strong><?php echo e($totalHari); ?> hari</strong></td>
            </tr>
          </table>
        </div>
        <div class="col-md-6">
          <table class="table table-sm">
            <tr>
              <th width="40%">Bulan Hijriah:</th>
              <td><?php echo e($inputData['bulan_h']); ?></td>
            </tr>
            <tr>
              <th>Tahun Hijriah:</th>
              <td><?php echo e($inputData['tahun_h']); ?> H</td>
            </tr>
            <tr>
              <th>Periode:</th>
              <td><?php echo e($periode); ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-header bg-warning text-dark">
      <i class="bi bi-table"></i> Preview Data Konversi (<?php echo e($totalHari); ?> hari)
    </div>
    <div class="card-body">
      <div class="table-responsive" style="max-height: 400px; overflow-y: auto;">
        <table class="table table-bordered table-hover table-striped">
          <thead class="table-dark" style="position: sticky; top: 0;">
            <tr>
              <th class="text-center">No</th>
              <th class="text-center">Tanggal Masehi</th>
              <th class="text-center">Tanggal Hijriah</th>
              <th class="text-center">Hari H</th>
              <th class="text-center">Bulan H</th>
              <th class="text-center">Tahun H</th>
            </tr>
          </thead>
          <tbody>
            <?php $__currentLoopData = $previewData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
              <td class="text-center"><?php echo e($index + 1); ?></td>
              <td class="text-center"><?php echo e($data['tanggal_masehi_formatted']); ?></td>
              <td class="text-center"><?php echo e($data['tanggal_hijriah']); ?></td>
              <td class="text-center"><?php echo e($data['hari_h']); ?></td>
              <td class="text-center"><?php echo e($data['bulan_h_nama']); ?></td>
              <td class="text-center"><?php echo e($data['tahun_h']); ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </tbody>
        </table>
      </div>
    </div>
  </div>

  <div class="card">
    <div class="card-header bg-primary text-white">
      <i class="bi bi-check-circle"></i> Konfirmasi Penyimpanan
    </div>
    <div class="card-body">
      <div class="alert alert-warning">
        <i class="bi bi-exclamation-triangle"></i> 
        <strong>Perhatian:</strong> Pastikan data di atas sudah benar sebelum menyimpan. 
        Data yang sudah disimpan tidak dapat diubah.
      </div>

      <form action="<?php echo e(route('konversiTanggal.store')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <!-- Tidak perlu hidden fields karena data sudah disimpan di session -->

        <div class="d-flex justify-content-between">
          <a href="<?php echo e(route('konversiTanggal.create')); ?>" class="btn btn-secondary">
            <i class="bi bi-arrow-left-circle"></i> Kembali & Edit
          </a>
          <button type="submit" class="btn btn-success">
            <i class="bi bi-save2"></i> Simpan Konversi
          </button>
        </div>
      </form>
    </div>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appform', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/konversiTanggal/preview.blade.php ENDPATH**/ ?>