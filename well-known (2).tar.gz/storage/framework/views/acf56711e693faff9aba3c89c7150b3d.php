
<?php $__env->startSection('title', 'Keranjang Realisasi'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h4 class="mb-3"><i class="bi bi-cart"></i> Keranjang Realisasi</h4>
    <div class="card mb-4">
        <div class="card-body">
            <?php if(empty($cartItems)): ?>
                <div class="alert alert-warning">Keranjang realisasi Anda kosong.</div>
            <?php else: ?>
                <div class="d-flex justify-content-between mb-3">
                    <div>
                        <h5>Akun: <?php echo e($akunInfo->kd_akun ?? ''); ?> - <?php echo e($akunInfo->nama_akun ?? ''); ?></h5>
                    </div>
                    <div>
                        <a href="<?php echo e(route('realisasi.emptyCart')); ?>" class="btn btn-danger me-2">
                            <i class="bi bi-trash me-1"></i> Kosongkan Keranjang
                        </a>
                        <a href="<?php echo e(route('realisasi.select')); ?>" class="btn btn-secondary">
                            <i class="bi bi-arrow-left me-1"></i> Kembali ke Pilih Target
                        </a>
                    </div>
                </div>
                
                <form action="<?php echo e(route('realisasi.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <div class="table-responsive">
                        <table class="table table-bordered">
                            <thead class="table-dark">
                                <tr>
                                    <th>Tanggal</th>
                                    <th>Kode Akun</th>
                                    <th>Nilai Target</th>
                                    <th width="200">Nilai Realisasi</th>
                                    <th width="250">Keterangan</th>
                                    <th width="50">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e(\Carbon\Carbon::parse($item['tanggal'])->format('d-m-Y')); ?></td>
                                    <td><?php echo e($item['kd_akun']); ?></td>
                                    <td class="text-end"><?php echo e(number_format($item['nilai_target'], 0, ',', '.')); ?></td>
                                    <td>
                                        <input type="number" 
                                               name="realisasi[<?php echo e($index); ?>][nilai]" 
                                               class="form-control" 
                                               value="<?php echo e($item['nilai_realisasi']); ?>" 
                                               required>
                                        <input type="hidden" 
                                               name="realisasi[<?php echo e($index); ?>][kd_target]" 
                                               value="<?php echo e($item['kd_target']); ?>">
                                        <input type="hidden" 
                                               name="realisasi[<?php echo e($index); ?>][tanggal]" 
                                               value="<?php echo e($item['tanggal']); ?>">
                                    </td>
                                    <td>
                                        <input type="text" 
                                               name="realisasi[<?php echo e($index); ?>][keterangan]" 
                                               class="form-control" 
                                               value="<?php echo e($item['keterangan']); ?>">
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('realisasi.removeFromCart', $index)); ?>" 
                                           class="btn btn-sm btn-danger"
                                           title="Hapus">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="d-flex justify-content-between mt-3">
                        <div class="text-muted">
                            Total Item: <?php echo e(count($cartItems)); ?>

                        </div>
                        <div>
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-save me-1"></i> Simpan Realisasi
                            </button>
                        </div>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/realisasi/cart.blade.php ENDPATH**/ ?>