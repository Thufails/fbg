
<?php $__env->startSection('content'); ?>
  <h3 class="mb-4"><i class="bi bi-diagram-3"></i> Tambah Data Entitas</h3>
  <form action="<?php echo e(route('entitas.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label class="form-label"><i class="bi bi-upc-scan"></i> Kode Entitas</label>
      <input type="text" name="kd_entitas" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-building"></i> Nama Entitas</label>
      <input type="text" name="nama_entitas" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-diagram-3"></i> Induk Entitas</label>
      <select name="induk" class="form-select">
      <option value="">-- Pilih Entitas Induk (opsional) --</option>
      <?php $__currentLoopData = $entitasList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $induk): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <option value="<?php echo e($induk->kd_entitas); ?>">
          <?php echo e($induk->kd_entitas); ?> - <?php echo e($induk->nama_entitas); ?>

        </option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-tag"></i> Keterangan</label>
      <input type="text" name="keterangan" class="form-control">
    </div>

    <div class="d-flex justify-content-between">
      <a href="<?php echo e(route('entitas.view')); ?>" class="btn btn-secondary">
        <i class="bi bi-arrow-left-circle"></i> Kembali
      </a>
      <button type="submit" class="btn btn-primary">
        <i class="bi bi-save2"></i> Simpan
      </button>
    </div>

  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appform', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/entitas/insert.blade.php ENDPATH**/ ?>