
<?php $__env->startSection('title', 'Pilih Tanggal Realisasi'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <h4 class="mb-3"><i class="bi bi-calendar-check"></i> Pilih Tanggal Realisasi</h4>  
  <!-- Search Form -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form action="<?php echo e(route('detailRealisasi.select')); ?>" method="GET" class="mb-0">
        <?php echo csrf_field(); ?>
        <div class="row g-3 align-items-end">
          <div class="col-md-2">
            <label for="start_date" class="form-label">Tanggal Awal</label>
            <input type="date" name="start_date" class="form-control" 
                   value="<?php echo e(request('start_date')); ?>" id="start_date">
          </div>
          <div class="col-md-2">
            <label for="end_date" class="form-label">Tanggal Akhir</label>
            <input type="date" name="end_date" class="form-control" 
                   value="<?php echo e(request('end_date')); ?>" id="end_date">
          </div>
          <div class="col-md-2">
            <label for="kd_detail_akun" class="form-label">Detail Akun</label>
            <select name="kd_detail_akun" class="form-select" id="kd_detail_akun">
              <option value="">Semua Detail Akun</option>
              <?php $__currentLoopData = $targetDetailList ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $targetDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($targetDetail->kd_detail_akun); ?>" <?php echo e(request('kd_detail_akun') == $targetDetail->kd_detail_akun ? 'selected' : ''); ?>>
                   <?php echo e($targetDetail->nama_akun); ?> - <?php echo e($targetDetail->nama_detail_akun); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-md-2">
            <label for="kd_entitas" class="form-label">Entitas</label>
            <select name="kd_entitas" class="form-select" id="kd_entitas">
              <option value="">Semua Entitas</option>
              <?php $__currentLoopData = $entitasList ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($entitas->kd_entitas); ?>" <?php echo e(request('kd_entitas') == $entitas->kd_entitas ? 'selected' : ''); ?>>
                  <?php echo e($entitas->kd_entitas); ?> - <?php echo e($entitas->nama_entitas); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-funnel me-1"></i> Filter
            </button>
            <?php if(request('start_date') || request('end_date') || request('kd_detail_akun') || request('kd_entitas')): ?>
            <a href="<?php echo e(route('detailRealisasi.select')); ?>" class="btn btn-secondary w-100 mt-2">
              <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
            </a>
            <?php endif; ?>
          </div>
        </div>
      </form>
    </div>
  </div>

  <?php if($targets->count() > 0): ?>
    <form action="<?php echo e(route('detailRealisasi.addToCart')); ?>" method="POST" id="addToCartForm">
      <?php echo csrf_field(); ?>      
      <input type="hidden" name="kd_detail_akun" value="<?php echo e($kd_detail_akun); ?>">
      <div class="card mb-4">
          <div class="card-header bg-light d-flex justify-content-between align-items-center flex-wrap">
              <h5 class="mb-0">Daftar Target Detail</h5>              
              <!-- Action Buttons Group -->
              <div class="btn-group" role="group">
                  <button type="submit" class="btn btn-primary btn-sm" id="addToCartBtn" disabled>
                      <i class="bi bi-cart-plus me-1"></i> Tambahkan ke Keranjang
                  </button>
                  <a href="<?php echo e(route('detailRealisasi.cart')); ?>" class="btn btn-info btn-sm">
                      <i class="bi bi-cart me-1"></i> Lihat Keranjang 
                      <?php if(session('cart') && count(session('cart')) > 0): ?>
                          <span class="badge bg-warning text-dark"><?php echo e(count(session('cart'))); ?></span>
                      <?php endif; ?>
                  </a>
              </div>
          </div>
          <div class="card-body">
              <div class="alert alert-info">
                  <i class="bi bi-info-circle me-1"></i>
                  Pilih target yang ingin ditambahkan ke keranjang dengan mencentang checkbox, kemudian klik tombol "Tambahkan ke Keranjang".
              </div>
              
              <div class="table-responsive">
                  <table class="table table-bordered table-hover align-middle">
                      <thead class="table-dark text-center">
                          <tr>
                              <th width="50">
                                  <input type="checkbox" id="selectAllTargets" class="form-check-input">
                              </th>
                              <th width="60">No</th>
                              <th>Tanggal</th>
                              <th>Entitas</th>
                              <th>Kode Target</th>
                              <th>Detail Akun</th>
                              <th>Nilai Target</th>
                              <th>Hari</th>
                              <th>Bulan</th>
                              <th>Tahun</th>
                          </tr>
                      </thead>
                      <tbody>
                          <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                          <tr>
                              <td class="text-center">
                                  <input type="checkbox" 
                                         name="selected_targets[]" 
                                         value="<?php echo e($target->kd_target_detail); ?>"
                                         data-tanggal="<?php echo e($target->tanggal); ?>"
                                         data-nilai="<?php echo e($target->nilai); ?>"
                                         data-kd-detail-akun="<?php echo e($target->kd_detail_akun); ?>"
                                         class="form-check-input target-checkbox">
                              </td>
                              <td class="text-center"><?php echo e(($targets->currentPage() - 1) * $targets->perPage() + $loop->iteration); ?></td>
                              <td><?php echo e(\Carbon\Carbon::parse($target->tanggal)->format('d-m-Y')); ?></td>
                              <td><?php echo e($target->nama_entitas ?? '-'); ?></td>
                              <td><?php echo e($target->kd_target_detail); ?></td>
                              <td><?php echo e($target->nama_detail_akun); ?></td>
                              <td class="text-end"><?php echo e(number_format($target->nilai, 0, ',', '.')); ?></td>
                              <td><?php echo e($target->hari); ?></td>
                              <td><?php echo e($target->bulan); ?></td>
                              <td><?php echo e($target->tahun); ?></td>
                          </tr>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </tbody>
                  </table>
              </div>
              
              <!-- Selected Items Summary -->
              <div id="selectedSummary" class="mt-3" style="display: none;">
                  <div class="alert alert-secondary">
                      <strong>Item yang dipilih: </strong>
                      <span id="selectedCount">0</span> target
                      <span class="ms-3"><strong>Total Nilai: </strong>Rp <span id="totalValue">0</span></span>
                  </div>
              </div>
          </div>
      </div>
  </form>
  <?php else: ?>
  <div class="alert alert-warning">
    <?php if(request('start_date') || request('end_date') || request('kd_detail_akun') || request('kd_entitas')): ?>
      Tidak ditemukan target dengan filter yang dipilih
    <?php else: ?>
      Tidak ada data target
    <?php endif; ?>
  </div>
  <?php endif; ?>

  <!-- Pagination -->
  <?php if($targets->hasPages()): ?>
  <div class="d-flex justify-content-center mt-4">
    <?php echo e($targets->withQueryString()->links()); ?>

  </div>
  <?php endif; ?>
</div>

<script>
document.addEventListener('DOMContentLoaded', function() {
  // Select all targets checkbox
  const selectAll = document.getElementById('selectAllTargets');
  const targetCheckboxes = document.querySelectorAll('.target-checkbox');
  const addToCartBtn = document.getElementById('addToCartBtn');
  const selectedSummary = document.getElementById('selectedSummary');
  const selectedCount = document.getElementById('selectedCount');
  const totalValue = document.getElementById('totalValue');
  
  // Function to update selected items summary
  function updateSummary() {
    const checkedBoxes = document.querySelectorAll('.target-checkbox:checked');
    const count = checkedBoxes.length;
    
    if (count > 0) {
      let total = 0;
      checkedBoxes.forEach(checkbox => {
        total += parseFloat(checkbox.dataset.nilai) || 0;
      });
      
      selectedCount.textContent = count;
      totalValue.textContent = new Intl.NumberFormat('id-ID').format(total);
      selectedSummary.style.display = 'block';
      addToCartBtn.disabled = false;
    } else {
      selectedSummary.style.display = 'none';
      addToCartBtn.disabled = true;
    }
  }
  
  // Select all functionality
  selectAll.addEventListener('change', function() {
    targetCheckboxes.forEach(checkbox => {
      checkbox.checked = this.checked;
    });
    updateSummary();
  });
  
  // Individual checkbox change
  targetCheckboxes.forEach(checkbox => {
    checkbox.addEventListener('change', function() {
      // Update select all checkbox state
      const checkedCount = document.querySelectorAll('.target-checkbox:checked').length;
      const totalCount = targetCheckboxes.length;
      
      if (checkedCount === 0) {
        selectAll.indeterminate = false;
        selectAll.checked = false;
      } else if (checkedCount === totalCount) {
        selectAll.indeterminate = false;
        selectAll.checked = true;
      } else {
        selectAll.indeterminate = true;
      }
      
      updateSummary();
    });
  });
  
  // Initial summary update
  updateSummary();
  
  // Form submission validation
  document.getElementById('addToCartForm').addEventListener('submit', function(e) {
    const checkedBoxes = document.querySelectorAll('.target-checkbox:checked');
    if (checkedBoxes.length === 0) {
      e.preventDefault();
      alert('Pilih minimal satu target untuk ditambahkan ke keranjang.');
      return false;
    }
  });
});
</script>

<style>
.btn-group .btn {
  margin-left: 5px;
}

.btn-group .btn:first-child {
  margin-left: 0;
}

@media (max-width: 768px) {
  .card-header .btn-group {
    margin-top: 10px;
    width: 100%;
  }
  
  .card-header .btn-group .btn {
    flex: 1;
    margin: 2px;
  }
  
  .card-header {
    flex-direction: column;
    align-items: stretch !important;
  }
}

.badge {
  font-size: 0.7em;
}

.form-check-input {
  cursor: pointer;
}
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/detailRealisasi/select_target.blade.php ENDPATH**/ ?>