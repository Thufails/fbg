
<?php $__env->startSection('content'); ?>
  <h3 class="mb-4"><i class="bi bi-plus-circle"></i> Tambah Data Produk</h3>
  <form action="<?php echo e(route('produk.store')); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <div class="mb-3">
      <label class="form-label"><i class="bi bi-upc-scan"></i> Kode Produk</label>
      <input type="text" name="kd_produk" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-box"></i> Nama Produk</label>
      <input type="text" name="nama_produk" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-cash-coin"></i> Harga</label>
      <input type="number" name="harga" class="form-control" required>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-card-text"></i> Keterangan</label>
      <textarea name="keterangan" class="form-control" rows="3"></textarea>
    </div>

    <div class="d-flex justify-content-between">
      <a href="<?php echo e(route('produk.view')); ?>" class="btn btn-secondary"><i class="bi bi-arrow-left-circle"></i> Kembali</a>
      <button type="submit" class="btn btn-primary"><i class="bi bi-save2"></i> Simpan</button>
    </div>

  </form>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.appform', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/produk/insert.blade.php ENDPATH**/ ?>