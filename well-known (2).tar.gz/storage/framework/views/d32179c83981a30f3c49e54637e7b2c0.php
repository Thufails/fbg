
<?php $__env->startSection('content'); ?>
<div class="container">
  <h3 class="mb-4"><i class="bi bi-journal-bookmark-fill text-primary"></i> Edit Detail Akun</h3>
  <form action="<?php echo e(route('detailAkun.update', $detailAkun->kd_detail_akun)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-3">
      <!-- Kode Detail Akun (readonly) -->
      <div class="col-md-6">
        <label class="form-label"><i class="bi bi-key text-primary"></i> Kode Detail Akun</label>
        <input type="text" name="kd_detail_akun" class="form-control" value="<?php echo e($detailAkun->kd_detail_akun); ?>" readonly>
        <input type="hidden" name="kd_akun" value="<?php echo e($detailAkun->kd_akun); ?>">
      </div>

      <!-- Akun Induk (readonly) dengan data dari join -->
      <div class="col-md-6">
        <label class="form-label"><i class="bi bi-diagram-2 text-primary"></i> Akun Induk</label>
        <input type="text" class="form-control" 
               value="<?php echo e($detailAkun->kd_akun); ?> - <?php echo e($detailAkun->nama_akun); ?>" 
               readonly>
        <input type="hidden" name="kd_akun" value="<?php echo e($detailAkun->kd_akun); ?>">
      </div>

      <!-- Nama Detail Akun -->
      <div class="col-12">
        <label class="form-label"><i class="bi bi-card-heading text-primary"></i> Nama Detail Akun</label>
        <input type="text" name="nama_detail_akun" class="form-control <?php $__errorArgs = ['nama_detail_akun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
               value="<?php echo e(old('nama_detail_akun', $detailAkun->nama_detail_akun)); ?>" 
               placeholder="Masukkan nama detail akun" required>
        <?php $__errorArgs = ['nama_detail_akun'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <!-- Keterangan -->
      <div class="col-12">
        <label class="form-label"><i class="bi bi-card-text text-primary"></i> Keterangan</label>
        <textarea name="keterangan" class="form-control <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" rows="3"
                  placeholder="Tambahkan keterangan jika diperlukan"><?php echo e(old('keterangan', $detailAkun->keterangan)); ?></textarea>
        <?php $__errorArgs = ['keterangan'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
          <div class="invalid-feedback"><?php echo e($message); ?></div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
      </div>

      <!-- Tombol Aksi -->
      <div class="col-12 d-flex justify-content-between mt-4">
        <a href="<?php echo e(route('akun.view')); ?>" class="btn btn-outline-secondary">
          <i class="bi bi-arrow-left-circle"></i> Kembali
        </a>
        <div>
          <button type="submit" class="btn btn-primary me-2">
            <i class="bi bi-save"></i> Simpan Perubahan
          </button>
          <button type="button" class="btn btn-danger" data-bs-toggle="modal" data-bs-target="#deleteModal">
            <i class="bi bi-trash"></i> Hapus
          </button>
        </div>
      </div>
    </div>
  </form>

  <!-- Modal Konfirmasi Hapus -->
  <div class="modal fade" id="deleteModal" tabindex="-1" aria-labelledby="deleteModalLabel" aria-hidden="true">
    <div class="modal-dialog">
      <div class="modal-content">
        <div class="modal-header">
          <h5 class="modal-title" id="deleteModalLabel">Konfirmasi Hapus</h5>
          <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
        </div>
        <div class="modal-body">
          Apakah Anda yakin ingin menghapus detail akun ini?
        </div>
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
          <form action="<?php echo e(route('detailAkun.destroy', $detailAkun->kd_detail_akun)); ?>" method="POST" style="display: inline;">
            <?php echo csrf_field(); ?>
            <?php echo method_field('DELETE'); ?>
            <button type="submit" class="btn btn-danger">Ya, Hapus</button>
          </form>
        </div>
      </div>
    </div>
  </div>
</div>

<style>
  .form-radio-group {
    display: flex;
    gap: 1.5rem;
  }
  .form-radio-item {
    display: flex;
    align-items: center;
  }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appform', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/detailAkun/edit.blade.php ENDPATH**/ ?>