
<?php $__env->startSection('title', 'Detail Target'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <h4 class="mb-3"><i class="bi bi-bullseye"></i> Detail Semua Target</h4>
  
  <div class="table-responsive">
    <table class="table table-bordered">
      <thead>
        <tr>
          <th>Tanggal</th>
          <th>Entitas</th>
          <th>Akun</th>
          <th>Nilai Target</th>
          <th>Detail</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $targets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $target): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($target->tanggal); ?></td>
          <td><?php echo e($target->entitas->nama_entitas); ?></td>
          <td><?php echo e($target->akun->nama_akun); ?></td>
          <td><?php echo e(number_format($target->nilai, 0, ',', '.')); ?></td>
          <td>
            <a href="<?php echo e(route('target.detail', $target->kd_target)); ?>" class="btn btn-sm btn-info">
              <i class="bi bi-eye"></i> Lihat
            </a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/target/detail.blade.php ENDPATH**/ ?>