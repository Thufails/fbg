
<?php $__env->startSection('title','Login'); ?>
<?php $__env->startSection('content'); ?>
<div class="row justify-content-center mt-5">
    <div class="col-md-6">
        <div class="card p-4">
            <h1>Login</h1>            
            <form action="<?php echo e(route('login.post')); ?>" method="post">
                <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
                <?php echo csrf_field(); ?>
                <div class="mb-2">
                    <label for="email" class="form-label">Email address</label>
                    <input type="email" class="form-control" id="email" value="<?php echo e(old('email')); ?>" name="email" aria-describedby="emailHelp">
                </div>
                <div class="mb-2">
                    <label for="password" class="form-label">Password</label>
                    <input type="password" class="form-control" name="password" id="password">
                </div>
                <div class="d-inline">
                    <button type="submit" class="btn btn-primary">Login Aplikasi</button>
                    <a href="<?php echo e(route('user.forgotPassword')); ?>">Lupa Password</a>
                </div>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.login', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/user/login.blade.php ENDPATH**/ ?>