
<?php $__env->startSection('title', 'Daftar Analisis'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <h4 class="mb-3"><i class="bi bi-file-earmark-bar-graph"></i> Data Analisis</h4>
  <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <a href="<?php echo e(route('analisis.insert')); ?>" class="btn btn-success mb-3">
    <i class="bi bi-plus-circle"></i> Tambah Analisis
  </a>

  <div class="table-responsive">
    <table class="table table-bordered table-hover">
      <thead class="table-dark">
        <tr>
          <th>No</th>
          <th>Tanggal Dibuat</th>
          <th>Uraian</th>
          <th>Bulan</th>
          <th>Tahun</th>
          <th>Dibuat Oleh</th>          
          <th width="180">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $analisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e(($analisis->currentPage() - 1) * $analisis->perPage() + $loop->iteration); ?></td>
          <td><?php echo e(\Carbon\Carbon::parse($item->created_at)->format('d-m-Y')); ?></td>
          <td><?php echo e(Str::limit($item->uraian, 50)); ?></td>
          <td><?php echo e($item->bulan); ?></td>
          <td><?php echo e($item->tahun); ?></td>
          <td><?php echo e($item->name ?? 'N/A'); ?></td>          
          <td class="text-center">
            <a href="<?php echo e(route('analisis.detail', $item->kd_analisis)); ?>" class="btn btn-info btn-sm" title="Detail">
              <i class="bi bi-eye"></i> 
            </a>
            
            <a href="<?php echo e(route('analisis.edit', $item->kd_analisis)); ?>" class="btn btn-warning btn-sm" title="Edit">
              <i class="bi bi-pencil-square"></i>
            </a>
            
            <form action="<?php echo e(route('analisis.destroy', $item->kd_analisis)); ?>" method="POST" class="d-inline">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger btn-sm" 
                      onclick="return confirm('Apakah Anda yakin ingin menghapus analisis ini?');" title="Hapus">
                <i class="bi bi-trash"></i>
              </button>
            </form>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if($analisis->hasPages()): ?>
  <div class="d-flex justify-content-center mt-3">
    <?php echo e($analisis->links()); ?>

  </div>
  <?php endif; ?>
</div>

<style>
  .table-dark {
    background: linear-gradient(135deg, #212529, #343a40);
  }
  
  .btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.75rem;
  }
  
  .table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.05);
  }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/analisis/view.blade.php ENDPATH**/ ?>