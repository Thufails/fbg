
<?php $__env->startSection('title', 'Detail Laporan'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
    <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <div class="card shadow-sm">
        <div class="card-header bg-primary text-white">
            <div class="d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="bi bi-file-earmark-text me-2"></i>Detail Laporan
                </h5>
                <span class="badge bg-light text-dark">
                    #<?php echo e($laporan->kd_laporan); ?>

                </span>
            </div>
        </div>
        
        <div class="card-body">
            <!-- Informasi Utama -->
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="mb-3">
                        <strong><i class="bi bi-calendar-date me-2"></i>Tanggal Laporan:</strong>
                        <p class="mt-1"><?php echo e(\Carbon\Carbon::parse($laporan->tanggal)->translatedFormat('d F Y')); ?></p>
                    </div>
                    
                    <div class="mb-3">
                        <strong><i class="bi bi-calendar-range me-2"></i>Periode Laporan:</strong>
                        <p class="mt-1">
                            <?php echo e(\Carbon\Carbon::parse($laporan->tanggal_awal)->translatedFormat('d F Y')); ?> - 
                            <?php echo e(\Carbon\Carbon::parse($laporan->tanggal_akhir)->translatedFormat('d F Y')); ?>

                        </p>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="mb-3">
                        <strong><i class="bi bi-activity me-2"></i>Status:</strong>
                        <p class="mt-1">
                            <?php if($laporan->status == 0): ?>
                                <span class="badge bg-secondary">
                                    <i class="bi bi-file-earmark-text"></i> Draft
                                </span>
                            <?php elseif($laporan->status == 1): ?>
                                <span class="badge bg-warning text-dark">
                                    <i class="bi bi-eye"></i> Dalam Review
                                </span>
                            <?php else: ?>
                                <span class="badge bg-success">
                                    <i class="bi bi-check-circle"></i> Disetujui
                                </span>
                            <?php endif; ?>
                        </p>
                    </div>
                    
                    <div class="mb-3">
                        <strong><i class="bi bi-person me-2"></i>Dibuat Oleh:</strong>
                        <p class="mt-1"><?php echo e($laporan->user->name ?? 'Tidak diketahui'); ?></p>
                    </div>
                </div>
            </div>
            
            <!-- Keterangan Laporan -->
            <div class="mb-4">
                <strong><i class="bi bi-card-text me-2"></i>Keterangan:</strong>
                <div class="card mt-2">
                    <div class="card-body bg-light">
                        <?php echo nl2br(e($laporan->keterangan)); ?>

                    </div>
                </div>
            </div>
            
            <!-- Timeline/Histori -->
            <div class="mb-4">
                <strong><i class="bi bi-clock-history me-2"></i>Timeline:</strong>
                <div class="timeline mt-3 ps-3">
                    <div class="timeline-item">
                        <div class="timeline-badge bg-primary"></div>
                        <div class="timeline-content">
                            <small class="text-muted">Dibuat pada: <?php echo e($laporan->created_at->translatedFormat('d M Y H:i')); ?></small>
                        </div>
                    </div>
                    <?php if($laporan->updated_at != $laporan->created_at): ?>
                    <div class="timeline-item">
                        <div class="timeline-badge bg-info"></div>
                        <div class="timeline-content">
                            <small class="text-muted">Terakhir diupdate: <?php echo e($laporan->updated_at->translatedFormat('d M Y H:i')); ?></small>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>

            
            
            

            
            <?php if($hasilAnalisis->count() > 0): ?>
                <div class="card mt-4">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3><i class="fas fa-chart-bar"></i> Hasil Analisis</h3>
                        <span class="badge bg-info">
                            Total: <?php echo e($hasilAnalisis->count()); ?> Analisis
                        </span>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <?php $__currentLoopData = $hasilAnalisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analisis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-md-6 col-lg-4 mb-3">
                                    <div class="card h-100 border-<?php echo e($analisis->status_analisis === 'Ada' ? 'success' : 'secondary'); ?>">
                                        <div class="card-header bg-<?php echo e($analisis->status_analisis === 'Ada' ? 'success' : 'secondary'); ?> text-white d-flex justify-content-between align-items-center">
                                            <span><?php echo e($analisis->title); ?></span>
                                            <?php if($analisis->status_analisis === 'Ada'): ?>
                                                <span class="badge bg-<?php echo e($analisis->jenis_analisis === 'AI' ? 'info' : 'warning'); ?> text-dark">
                                                    <?php echo e($analisis->jenis_analisis === 'AI' ? 'AI' : 'Manual'); ?>

                                                </span>
                                            <?php endif; ?>
                                        </div>
                                        <div class="card-body">
                                            <div class="d-flex justify-content-between mb-2">
                                                <span>Data:</span>
                                                <span class="badge bg-<?php echo e($analisis->status_data === 'Ada' ? 'success' : 'secondary'); ?>">
                                                    <?php echo e($analisis->status_data); ?>

                                                </span>
                                            </div>
                                            <div class="d-flex justify-content-between mb-3">
                                                <span>Analisis:</span>
                                                <span class="badge bg-<?php echo e($analisis->status_analisis === 'Ada' ? 'success' : 'secondary'); ?>">
                                                    <?php echo e($analisis->status_analisis); ?>

                                                </span>
                                            </div>
                                            
                                            
                                            <?php if($analisis->status_analisis === 'Ada'): ?>
                                                <div class="mb-3">
                                                    <small class="text-muted">Jenis: <?php echo e($analisis->jenis_analisis === 'AI' ? 'Analisis AI' : 'Analisis Manual'); ?></small>
                                                </div>
                                                <div class="analysis-preview mb-3">
                                                    <small class="text-muted">Preview:</small>
                                                    <div class="mt-1 p-2 bg-light rounded" style="max-height: 100px; overflow: hidden;">
                                                        <?php echo Str::limit(strip_tags($analisis->analisis), 100); ?>

                                                    </div>
                                                </div>
                                            <?php endif; ?>
                                            
                                            
                                            <form action="<?php echo e(route('laporan.analyze')); ?>" method="POST" onsubmit="return validateAnalyzeForm(this)">
                                                <?php echo csrf_field(); ?>
                                                <input type="hidden" name="kd_laporan" value="<?php echo e($laporan->kd_laporan); ?>">
                                                <input type="hidden" name="title" value="<?php echo e($analisis->title); ?>">
                                                
                                                <?php if($analisis->status_data === 'Ada'): ?>
                                                    <button type="submit" class="btn btn-primary btn-sm w-100">
                                                        <i class="fas fa-robot"></i> 
                                                        <?php echo e($analisis->status_analisis === 'Ada' ? 'Reanalyze' : 'Analyze'); ?>

                                                    </button>
                                                <?php endif; ?>
                                            </form>
                                            
                                            
                                            <?php if($analisis->status_analisis === 'Ada'): ?>
                                                <button type="button" class="btn btn-outline-info btn-sm w-100 mt-2" data-bs-toggle="modal" data-bs-target="#analysisModal<?php echo e($loop->index); ?>">
                                                    <i class="fas fa-eye"></i> View Analysis
                                                </button>
                                            <?php endif; ?>
                                        </div>
                                        <div class="card-footer bg-light">
                                            <small class="text-muted">
                                                <i class="fas fa-clock"></i> 
                                                Diupdate: <?php echo e(\Carbon\Carbon::parse($analisis->updated_at)->format('d M Y H:i')); ?>

                                            </small>
                                        </div>
                                    </div>
                                </div>
                                
                                
                                <?php if($analisis->status_analisis === 'Ada'): ?>
                                <div class="modal fade" id="analysisModal<?php echo e($loop->index); ?>" tabindex="-1" aria-hidden="true">
                                    <div class="modal-dialog modal-xl">
                                        <div class="modal-content">
                                            <div class="modal-header bg-<?php echo e($analisis->jenis_analisis === 'AI' ? 'info' : 'warning'); ?> text-white">
                                                <h5 class="modal-title">
                                                    <?php echo e($analisis->title); ?> - <?php echo e($analisis->jenis_analisis === 'AI' ? 'Analisis AI' : 'Analisis Manual'); ?>

                                                </h5>
                                                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                                            </div>
                                            <form action="<?php echo e(route('laporan.update.analysis', $analisis->kd_hasil_analisis)); ?>" method="POST">
                                                <?php echo csrf_field(); ?>
                                                <?php echo method_field('PUT'); ?>
                                                <div class="modal-body">
                                                    <div class="mb-3">
                                                        <textarea id="editor<?php echo e($loop->index); ?>" name="analisis" class="form-control" rows="15">
                                                            <?php echo $analisis->analisis; ?>

                                                        </textarea>
                                                    </div>
                                                    
                                                    <div class="alert alert-info">
                                                        <i class="fas fa-info-circle"></i> Anda dapat mengedit analisis ini menggunakan editor di atas.
                                                        Klik "Simpan Perubahan" untuk menyimpan hasil edit.
                                                    </div>
                                                </div>
                                                <div class="modal-footer">
                                                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                                                    <button type="submit" class="btn btn-primary">
                                                        <i class="fas fa-save"></i> Simpan Perubahan
                                                    </button>
                                                </div>
                                            </form>
                                        </div>
                                    </div>
                                </div>
                                <?php endif; ?>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                </div>
            <?php else: ?>
                <div class="alert alert-info mt-4">
                    <i class="fas fa-info-circle"></i> Belum ada hasil analisis untuk laporan ini.
                </div>
            <?php endif; ?>
        </div>        
        <div class="card-footer bg-light">
            <div class="d-flex justify-content-between">
                <a href="<?php echo e(route('laporan.view')); ?>" class="btn btn-secondary">
                    <i class="bi bi-arrow-left me-1"></i> Kembali
                </a>
                <div>
                    
                    <a href="<?php echo e(route('laporan.preview_report', $laporan->kd_laporan)); ?>" class="btn btn-info me-2">
                        <i class="bi bi-eye me-1"></i> Preview Laporan
                    </a>
                    
                    <a href="<?php echo e(route('laporan.edit', $laporan->kd_laporan)); ?>" class="btn btn-warning me-2">
                        <i class="bi bi-pencil-square me-1"></i> Edit
                    </a>
                    <button class="btn btn-danger" onclick="confirmDelete()">
                        <i class="bi bi-trash me-1"></i> Hapus
                    </button>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Delete Confirmation Modal -->
<div class="modal fade" id="deleteModal" tabindex="-1" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header bg-danger text-white">
                <h5 class="modal-title">Konfirmasi Hapus</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                Apakah Anda yakin ingin menghapus laporan ini?
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Batal</button>
                <form action="<?php echo e(route('laporan.destroy', $laporan->kd_laporan)); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>
                    <button type="submit" class="btn btn-danger">
                        <i class="bi bi-trash me-1"></i> Hapus
                    </button>
                </form>
            </div>
        </div>
    </div>
</div>

<style>
    .timeline {
        position: relative;
        border-left: 2px solid #dee2e6;
    }
    .timeline-item {
        position: relative;
        padding-bottom: 1rem;
    }
    .timeline-badge {
        position: absolute;
        left: -8px;
        width: 14px;
        height: 14px;
        border-radius: 50%;
        top: 4px;
    }
    .timeline-content {
        margin-left: 15px;
    }
</style>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    function confirmDelete() {
        var modal = new bootstrap.Modal(document.getElementById('deleteModal'));
        modal.show();
    }

    document.addEventListener('DOMContentLoaded', function() {
        // Inisialisasi CKEditor untuk setiap modal analisis
        <?php $__currentLoopData = $hasilAnalisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $analisis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($analisis->status_analisis === 'Ada'): ?>
                ClassicEditor
                    .create(document.querySelector('#editor<?php echo e($index); ?>'), {
                        toolbar: [
                            'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 
                            'numberedList', '|', 'undo', 'redo'
                        ]
                    })
                    .catch(error => {
                        console.error(error);
                    });
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        // Inisialisasi CKEditor untuk modal kesimpulan
        <?php $__currentLoopData = $hasilAnalisis; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $analisis): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <?php if($analisis->title === 'Kesimpulan dan Saran'): ?>
                ClassicEditor
                    .create(document.querySelector('#conclusionContent'), {
                        toolbar: [
                            'heading', '|', 'bold', 'italic', 'link', 'bulletedList', 
                            'numberedList', '|', 'undo', 'redo'
                        ]
                    })
                    .catch(error => {
                        console.error(error);
                    });
                <?php break; ?>
            <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    });
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/laporan/detail.blade.php ENDPATH**/ ?>