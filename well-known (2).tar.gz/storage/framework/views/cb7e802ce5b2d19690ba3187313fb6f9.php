
<?php $__env->startSection('title', 'Master Entitas'); ?>
<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('layouts.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <h4 class="mb-3"><i class="bi bi-diagram-3-fill"></i> Data Entitas</h4>
  <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <a href="<?php echo e(route('entitas.insert')); ?>" class="btn btn-success mb-3">
    <i class="bi bi-plus-circle"></i> Tambah Entitas
  </a>

  <div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
      <thead class="table-dark text-center">
        <tr>
          <th>No</th>
          <th>Kode</th>
          <th>Nama Entitas</th>
          <th>Induk</th>
          <th>Keterangan</th>
          <th>Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $entitas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($loop->iteration); ?></td>
          <td><?php echo e($item->kd_entitas); ?></td>
          <td><?php echo e($item->nama_entitas); ?></td>
          <td><?php echo e($item->induk); ?></td>
          <td><?php echo e($item->keterangan); ?></td>
          <td>
            <a href="<?php echo e(route('entitas.edit', $item->kd_entitas)); ?>" class="btn btn-warning btn-sm"><i class="bi bi-pencil-square"></i></a>
            <form action="<?php echo e(route('entitas.destroy', $item->kd_entitas)); ?>" method="POST" style="display:inline;">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Apakah Anda yakin ingin menghapus entitas ini?');">
                <i class="bi bi-trash"></i>
              </button>
            </form>
          </td>
        </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <!-- Tambahkan data dari database -->
      </tbody>
    </table>
  </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/entitas/view.blade.php ENDPATH**/ ?>