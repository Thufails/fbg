
<?php $__env->startSection('title', 'Keranjang Realisasi'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h4 class="mb-3"><i class="bi bi-cart"></i> Keranjang Realisasi</h4>
    
    <div class="card mb-4">
        <div class="card-body">
            <?php if(empty($cartItems)): ?>
                <div class="alert alert-warning">Keranjang realisasi Anda kosong.</div>
            <?php else: ?>
                <div class="d-flex justify-content-between align-items-center mb-3">
                    <div>
                        <h5>Detail Akun: <?php echo e($akunInfo->kd_detail_akun ?? ''); ?> - <?php echo e($akunInfo->nama_detail_akun ?? ''); ?></h5>
                    </div>
                    <div>
                        <a href="<?php echo e(route('detailRealisasi.emptyCart')); ?>" class="btn btn-danger me-2">
                            <i class="bi bi-trash me-1"></i> Kosongkan Keranjang
                        </a>
                        <a href="<?php echo e(route('detailRealisasi.select')); ?>" class="btn btn-secondary">
                            <i class="bi bi-arrow-left me-1"></i> Kembali ke Pilih Target
                        </a>
                    </div>
                </div>
                
                <!-- Form untuk menyimpan realisasi -->
                <form action="<?php echo e(route('detailRealisasi.store')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    
                    <div class="table-responsive">
                        <table class="table table-bordered table-hover align-middle">
                            <thead class="table-dark text-center">
                                <tr>
                                    <th width="60">No</th>
                                    <th>Tanggal</th>
                                    <th>Akun Detail</th>
                                    <th>Nilai Realisasi</th>
                                    <th>Keterangan</th>
                                    <th width="100">Aksi</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                    <td><?php echo e(\Carbon\Carbon::parse($item['tanggal'])->format('d-m-Y')); ?></td>
                                    <td><?php echo e($item['nama_detail_akun']); ?></td>
                                    <td>
                                        <input type="number" 
                                               name="realisasi[<?php echo e($index); ?>][nilai]" 
                                               class="form-control" 
                                               value="<?php echo e($item['nilai'] ?? 0); ?>" 
                                               required>
                                        <input type="hidden" 
                                               name="realisasi[<?php echo e($index); ?>][tanggal]" 
                                               value="<?php echo e($item['tanggal']); ?>">
                                        <input type="hidden" 
                                               name="realisasi[<?php echo e($index); ?>][kd_target_detail]" 
                                               value="<?php echo e($item['kd_target_detail']); ?>">
                                    </td>
                                    <td>
                                        <input type="text" 
                                               name="realisasi[<?php echo e($index); ?>][keterangan]" 
                                               class="form-control" 
                                               value="<?php echo e($item['keterangan'] ?? ''); ?>">
                                    </td>
                                    <td class="text-center">
                                        <a href="<?php echo e(route('detailRealisasi.removeFromCart', $index)); ?>" 
                                           class="btn btn-danger btn-sm"
                                           onclick="return confirm('Hapus item ini dari keranjang?')">
                                            <i class="bi bi-trash"></i>
                                        </a>
                                    </td>
                                </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                    
                    <div class="d-flex justify-content-end mt-3">
                        <button type="submit" class="btn btn-primary">
                            <i class="bi bi-save me-1"></i> Simpan Realisasi
                        </button>
                    </div>
                </form>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/detailRealisasi/cart.blade.php ENDPATH**/ ?>