
<?php $__env->startSection('content'); ?>
  <h3 class="mb-4"><i class="bi bi-calendar-check"></i> Edit Konversi Tanggal</h3>
  <form action="<?php echo e(route('konversiTanggal.update', $konversi_tanggal->id)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="mb-3">
      <label class="form-label"><i class="bi bi-calendar-date"></i> Tanggal Masehi</label>
      <input type="date" name="tanggal" class="form-control <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" 
             value="<?php echo e(old('tanggal', \Carbon\Carbon::parse($konversi_tanggal->tanggal)->format('Y-m-d'))); ?>" required>
      <?php $__errorArgs = ['tanggal'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
        <div class="invalid-feedback"><?php echo e($message); ?></div>
      <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    </div>

    <div class="mb-3">
      <label class="form-label"><i class="bi bi-calendar-event"></i> Tanggal Hijriah Saat Ini</label>
      <input type="text" class="form-control bg-light" value="<?php echo e($konversi_tanggal->tanggal_h); ?>" readonly>
      <small class="text-muted">Tanggal hijriah akan diperbarui otomatis setelah data disimpan</small>
    </div>

    <div class="alert alert-warning">
      <i class="bi bi-exclamation-triangle"></i> 
      <strong>Perhatian:</strong> Mengubah tanggal masehi akan mengubah hasil konversi hijriah.
    </div>

    <div class="d-flex justify-content-between">
      <a href="<?php echo e(route('konversiTanggal.view')); ?>" class="btn btn-secondary">
        <i class="bi bi-arrow-left-circle"></i> Kembali
      </a>
      <button type="submit" class="btn btn-primary">
        <i class="bi bi-save2"></i> Update
      </button>
    </div>

  </form>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appform', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/konversiTanggal/edit.blade.php ENDPATH**/ ?>