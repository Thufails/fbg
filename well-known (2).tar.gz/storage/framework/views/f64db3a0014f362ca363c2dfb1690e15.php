
<?php $__env->startSection('title', 'Daftar Komplain'); ?>
<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('layouts.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <h4 class="mb-3"><i class="bi bi-megaphone-fill"></i> Data Komplain</h4>
  <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Form Pencarian dengan Card - Hanya Tanggal -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form action="<?php echo e(route('komplain.view')); ?>" method="GET" class="mb-0">
        <div class="row g-3 align-items-end">
          <div class="col-md-5">
            <label for="start_date" class="form-label">Tanggal Awal</label>
            <input type="date" name="start_date" class="form-control" 
                   value="<?php echo e(request('start_date')); ?>" id="start_date">
          </div>
          <div class="col-md-5">
            <label for="end_date" class="form-label">Tanggal Akhir</label>
            <input type="date" name="end_date" class="form-control" 
                   value="<?php echo e(request('end_date')); ?>" id="end_date">
          </div>
          <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-funnel me-1"></i> Filter
            </button>
            <?php if(request('start_date') || request('end_date')): ?>
            <a href="<?php echo e(route('komplain.view')); ?>" class="btn btn-secondary w-100 mt-2">
              <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
            </a>
            <?php endif; ?>
          </div>
        </div>
      </form>
    </div>
  </div>

  <!-- Info Hasil Filter -->
  <?php if(request('start_date') || request('end_date')): ?>
  <div class="alert alert-info mb-3">
    <i class="bi bi-info-circle"></i> Menampilkan komplain dari tanggal 
    <strong><?php echo e(request('start_date') ? \Carbon\Carbon::parse(request('start_date'))->format('d-m-Y') : 'Awal'); ?></strong> 
    sampai 
    <strong><?php echo e(request('end_date') ? \Carbon\Carbon::parse(request('end_date'))->format('d-m-Y') : 'Akhir'); ?></strong>
    <a href="<?php echo e(route('komplain.view')); ?>" class="float-end text-decoration-none">
      <i class="bi bi-x"></i> Hapus filter
    </a>
  </div>
  <?php endif; ?>

  <!-- Baris Info Jumlah Data dan Tombol Tambah -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div class="text-muted">
      Menampilkan <?php echo e($komplain->firstItem() ?? 0); ?> - <?php echo e($komplain->lastItem() ?? 0); ?> dari <?php echo e($komplain->total() ?? 0); ?> komplain
    </div>
    <a href="<?php echo e(route('komplain.insert')); ?>" class="btn btn-success">
      <i class="bi bi-plus-circle me-1"></i> Tambah Komplain
    </a>
  </div>

  <div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
      <thead class="table-dark text-center">
        <tr>
          <th width="60">No</th>
          <th>Tanggal</th>
          <th>Deskripsi Komplain</th>
          <th>Bulan</th>
          <th>Tahun</th>
          <th>Status</th>
          <th>User</th>
          <th width="150">Aksi</th>
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $komplain; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="text-center"><?php echo e(($komplain->currentPage() - 1) * $komplain->perPage() + $loop->iteration); ?></td>
          <td><?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d-m-Y')); ?></td>
          <td><?php echo e(Str::limit($item->uraian, 50)); ?></td>
          <td><?php echo e($item->bulan); ?></td>
          <td><?php echo e($item->tahun); ?></td>
          <td class="text-center">
            <?php if($item->status == 'Open'): ?>
              <span class="badge bg-danger"><i class="bi bi-exclamation-circle"></i> Open</span>
            <?php elseif($item->status == 'Proses'): ?>
              <span class="badge bg-warning text-dark"><i class="bi bi-arrow-repeat"></i> Proses</span>
            <?php else: ?>
              <span class="badge bg-success"><i class="bi bi-check-circle"></i> Closed</span>
            <?php endif; ?>
          </td>
          <td><?php echo e($item->name); ?></td>
          <td class="text-center">
            <a href="<?php echo e(route('komplain.edit', $item->kd_komplain)); ?>" class="btn btn-warning btn-sm" title="Edit">
              <i class="bi bi-pencil-square"></i>
            </a>
            <form action="<?php echo e(route('komplain.destroy', $item->kd_komplain)); ?>" method="POST" class="d-inline">
              <?php echo csrf_field(); ?>
              <?php echo method_field('DELETE'); ?>
              <button type="submit" class="btn btn-danger btn-sm" 
                      onclick="return confirm('Apakah Anda yakin ingin menghapus komplain ini?');" title="Hapus">
                <i class="bi bi-trash"></i>
              </button>
            </form>
            <a href="<?php echo e(route('komplain.detail', $item->kd_komplain)); ?>" class="btn btn-info btn-sm" title="Detail">
              <i class="bi bi-eye"></i>
            </a>
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="8" class="text-center py-4">
            <?php if(request('start_date') || request('end_date')): ?>
              Tidak ditemukan komplain pada periode yang dipilih
            <?php else: ?>
              Tidak ada data komplain
            <?php endif; ?>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if($komplain->hasPages()): ?>
  <div class="d-flex justify-content-center mt-4">
    <?php echo e($komplain->withQueryString()->links()); ?>

  </div>
  <?php endif; ?>
</div>

<style>
  /* Style untuk tabel */
  .table {
    font-size: 0.9rem;
  }
  
  .table-dark {
    background-color: #212529;
  }
  
  .table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.05);
  }
  
  /* Style untuk badge status */
  .badge.bg-danger { background-color: #dc3545 !important; }
  .badge.bg-warning { background-color: #ffc107 !important; }
  .badge.bg-success { background-color: #198754 !important; }
  
  /* Style untuk tombol aksi */
  .btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.75rem;
  }
  
  /* Style untuk card pencarian */
  .card {
    border-radius: 0.5rem;
    border: 1px solid #dee2e6;
  }
  
  /* Style untuk alert pencarian */
  .alert-info {
    background-color: #e7f8ff;
    border-color: #b6e7ff;
    color: #055160;
  }
</style>

<script>
// Auto focus ke input tanggal awal saat halaman dimuat
document.addEventListener('DOMContentLoaded', function() {
    const startDateInput = document.getElementById('start_date');
    if (startDateInput) {
        startDateInput.focus();
    }
    
    // Validasi tanggal akhir tidak boleh sebelum tanggal awal
    const endDateInput = document.getElementById('end_date');
    if (startDateInput && endDateInput) {
        startDateInput.addEventListener('change', function() {
            if (endDateInput.value && new Date(endDateInput.value) < new Date(this.value)) {
                endDateInput.value = this.value;
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/komplain/view.blade.php ENDPATH**/ ?>