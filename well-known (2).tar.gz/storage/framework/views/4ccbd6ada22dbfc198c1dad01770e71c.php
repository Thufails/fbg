
<?php $__env->startSection('title', 'Keranjang'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h4 class="mb-3">Keranjang</h4>
    <div class="card mb-4">
        <div class="card-body">
            <?php if(empty($cartItems)): ?>
                <div class="alert alert-warning">Keranjang Anda kosong.</div>
            <?php else: ?>
                <!-- Form untuk menyimpan ke tabel detail_target -->
                <div class="card mb-4">
                    <div class="card-header bg-primary text-white">
                        <h5 class="mb-0">Simpan Target Detail</h5>
                    </div>
                    <div class="card-body">
                        <form action="<?php echo e(route('detailTarget.store')); ?>" method="POST">
                            <?php echo csrf_field(); ?>
                            
                            <div class="row mb-3">
                                <div class="col-md-4">
                                    <label for="kd_detail_akun" class="form-label">Detail Akun</label>
                                    <select name="kd_detail_akun" id="kd_detail_akun" class="form-select" required>
                                        <option value="">Pilih Detail Akun</option>
                                        <?php $__currentLoopData = $detailAkunList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $detailAkun): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($detailAkun->kd_detail_akun); ?>" 
                                                <?php if(session('kd_akun') == $detailAkun->kd_akun): ?> selected <?php endif; ?>>
                                                <?php echo e($detailAkun->kd_detail_akun); ?> - <?php echo e($detailAkun->nama_detail_akun); ?>

                                            </option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="col-md-4">
                                    <label for="nilai" class="form-label">Nilai</label>
                                    <input type="number" name="nilai" id="nilai" class="form-control" required 
                                           placeholder="Masukkan nilai">
                                </div>
                            </div>
                            
                            <input type="hidden" name="cart_items" value="<?php echo e(json_encode($cartItems)); ?>">
                            
                            <div class="d-flex justify-content-between align-items-center">
                                <button type="submit" class="btn btn-primary">
                                    <i class="bi bi-save"></i> Simpan Detail Target
                                </button>
                                
                                <a href="<?php echo e(route('detailTarget.empty')); ?>" class="btn btn-danger">
                                    <i class="bi bi-trash"></i> Kosongkan Keranjang
                                </a>
                            </div>
                        </form>
                    </div>
                </div>

                <!-- Tabel keranjang -->
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead class="table-dark">
                            <tr>
                                <th width="50">No</th>
                                <th>Tanggal</th>
                                <th>Kode Akun</th>
                                <th>Nilai</th>
                                <th width="120">Aksi</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $cartItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $index => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td class="text-center"><?php echo e($loop->iteration); ?></td>
                                <td><?php echo e(\Carbon\Carbon::parse($item['tanggal'])->format('d-m-Y')); ?></td>
                                <td><?php echo e($item['kd_akun']); ?></td>
                                <td class="text-end"><?php echo e(isset($item['nilai']) ? number_format($item['nilai'], 0, ',', '.') : '-'); ?></td>
                                <td class="text-center">
                                    <form action="<?php echo e(route('detailTarget.item.remove', $index)); ?>" method="POST" style="display:inline;">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('DELETE'); ?>
                                        <button type="submit" class="btn btn-danger btn-sm">
                                            <i class="bi bi-trash"></i> Hapus
                                        </button>
                                    </form>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                </div>
            <?php endif; ?>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/detailTarget/cart.blade.php ENDPATH**/ ?>