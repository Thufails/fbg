
<?php $__env->startSection('title', 'Daftar Laporan'); ?>
<?php $__env->startSection('nav'); ?>
<?php echo $__env->make('layouts.nav', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <h4 class="mb-3"><i class="bi bi-file-earmark-text"></i> Data Laporan</h4>
  <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Form Pencarian dengan Card - Hanya Tanggal -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form action="<?php echo e(route('laporan.view')); ?>" method="GET" class="mb-0">
        <div class="row g-3 align-items-end">
          <div class="col-md-5">
            <label for="start_date" class="form-label">Tanggal Awal</label>
            <input type="date" name="start_date" class="form-control" value="<?php echo e(request('start_date')); ?>" id="start_date">
          </div>
          <div class="col-md-5">
            <label for="end_date" class="form-label">Tanggal Akhir</label>
            <input type="date" name="end_date" class="form-control" 
                   value="<?php echo e(request('end_date')); ?>" id="end_date">
          </div>
          <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-funnel me-1"></i> Filter
            </button>
            <?php if(request('start_date') || request('end_date')): ?>
            <a href="<?php echo e(route('laporan.view')); ?>" class="btn btn-secondary w-100 mt-2">
              <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
            </a>
            <?php endif; ?>
          </div>
        </div>
      </form>
    </div>
  </div>

  <!-- Info Hasil Filter -->
  <?php if(request('start_date') || request('end_date')): ?>
  <div class="alert alert-info mb-3">
    <i class="bi bi-info-circle"></i> Menampilkan laporan dari tanggal 
    <strong><?php echo e(request('start_date') ? \Carbon\Carbon::parse(request('start_date'))->format('d-m-Y') : 'Awal'); ?></strong> 
    sampai 
    <strong><?php echo e(request('end_date') ? \Carbon\Carbon::parse(request('end_date'))->format('d-m-Y') : 'Akhir'); ?></strong>
    <a href="<?php echo e(route('laporan.view')); ?>" class="float-end text-decoration-none">
      <i class="bi bi-x"></i> Hapus filter
    </a>
  </div>
  <?php endif; ?>

  <!-- Baris Info Jumlah Data dan Tombol Tambah -->
  <div class="d-flex justify-content-between align-items-center mb-3">
    <div class="text-muted">
      Menampilkan <?php echo e($laporan->firstItem() ?? 0); ?> - <?php echo e($laporan->lastItem() ?? 0); ?> dari <?php echo e($laporan->total() ?? 0); ?> laporan
    </div>
    <?php if(!empty($item->path_pdf) &&  (Auth::user()->level === 'admin' || Auth::user()->level != 'guest')): ?>
    <a href="<?php echo e(route('laporan.insert')); ?>" class="btn btn-success">
      <i class="bi bi-plus-circle me-1"></i> Tambah Laporan
    </a>
    <?php endif; ?>
  </div>

  <div class="table-responsive">
    <table class="table table-bordered table-hover align-middle">
      <thead class="table-dark text-center">
        <tr>
          <th width="60">No</th>
          <th>Tanggal Laporan</th>
          <th>Periode</th>
          <th>Dibuat Oleh</th>
          <th>Keterangan</th>
          <th width="200">Aksi</th> <!-- Increased width for action column -->
        </tr>
      </thead>
      <tbody>
        <?php $__empty_1 = true; $__currentLoopData = $laporan; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
        <tr>
          <td class="text-center"><?php echo e(($laporan->currentPage() - 1) * $laporan->perPage() + $loop->iteration); ?></td>
          <td><?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d-m-Y')); ?></td>
          <td>
            <?php echo e(\Carbon\Carbon::parse($item->tanggal_awal)->format('d-m-Y')); ?> - 
            <?php echo e(\Carbon\Carbon::parse($item->tanggal_akhir)->format('d-m-Y')); ?>

          </td>
          <td><?php echo e($item->name ?? 'N/A'); ?></td>
          <td><?php echo e(Str::limit($item->keterangan, 50)); ?></td>
          <td class="text-center">
            
            <div class="d-flex justify-content-center gap-1"> <!-- Flexbox for better alignment -->
              <!-- Ganti bagian tombol PDF dengan dropdown -->
              <?php if(!empty($item->path_pdf) &&  (Auth::user()->level === 'admin' || Auth::user()->level === 'guest')): ?>
              <div class="btn-group">
                <button type="button" class="btn btn-primary btn-sm dropdown-toggle" data-bs-toggle="dropdown" aria-expanded="false">
                  <i class="bi bi-file-pdf"></i> PDF
                </button>
                <ul class="dropdown-menu">
                  <li><a class="dropdown-item" href="<?php echo e(route('laporan.view.pdf', $item->kd_laporan)); ?>" target="_blank">
                    <i class="bi bi-eye me-2"></i> View
                  </a></li>
                  <li><a class="dropdown-item" href="<?php echo e(route('laporan.download.pdf', $item->kd_laporan)); ?>">
                    <i class="bi bi-download me-2"></i> Download
                  </a></li>
                </ul>
              </div>
              <?php endif; ?>
            
              <?php if(Auth::check() && (Auth::user()->level === 'admin' || Auth::user()->level === 'user' || Auth::user()->level === 'analis')): ?>               

                <a href="<?php echo e(route('laporan.detail', $item->kd_laporan)); ?>" class="btn btn-info btn-sm" title="Detail Laporan">
                  <i class="bi bi-info-circle-fill"></i> Detail
                </a>
                <a href="<?php echo e(route('laporan.edit', $item->kd_laporan)); ?>" class="btn btn-warning btn-sm" title="Edit">
                  <i class="bi bi-pencil-square"></i>Edit
                </a>
                <!-- Tombol Generate -->
                
                <a href="<?php echo e(route('laporan.final_report', $item->kd_laporan)); ?>" class="btn btn-secondary btn-sm" title="Lihat Laporan Bulanan">
                    <i class="bi bi-eye-fill"></i>Generate
                </a>              
                <form action="<?php echo e(route('laporan.destroy', $item->kd_laporan)); ?>" method="POST" class="d-inline">
                  <?php echo csrf_field(); ?>
                  <?php echo method_field('DELETE'); ?>
                  <button type="submit" class="btn btn-danger btn-sm" 
                          onclick="return confirm('Apakah Anda yakin ingin menghapus laporan ini?');" title="Hapus">
                    <i class="bi bi-trash"></i>Delete
                  </button>
                </form>
              <?php endif; ?>
            </div>            
          </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
        <tr>
          <td colspan="6" class="text-center py-4">
            <?php if(request('start_date') || request('end_date')): ?>
              Tidak ditemukan laporan pada periode yang dipilih
            <?php else: ?>
              Tidak ada data laporan
            <?php endif; ?>
          </td>
        </tr>
        <?php endif; ?>
      </tbody>
    </table>
  </div>

  <!-- Pagination -->
  <?php if($laporan->hasPages()): ?>
  <div class="d-flex justify-content-center mt-4">
    <?php echo e($laporan->withQueryString()->links()); ?>

  </div>
  <?php endif; ?>
</div>

<script>
// Auto focus ke input tanggal awal saat halaman dimuat
document.addEventListener('DOMContentLoaded', function() {
    const startDateInput = document.getElementById('start_date');
    if (startDateInput) {
        startDateInput.focus();
    }
    
    // Validasi tanggal akhir tidak boleh sebelum tanggal awal
    const endDateInput = document.getElementById('end_date');
    if (startDateInput && endDateInput) {
        startDateInput.addEventListener('change', function() {
            if (endDateInput.value && new Date(endDateInput.value) < new Date(this.value)) {
                endDateInput.value = this.value;
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/laporan/view.blade.php ENDPATH**/ ?>