
<?php $__env->startSection('title', 'Master Users'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h4 class="mb-3"><i class="bi bi-people-fill"></i> Daftar Users</h4>
    <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
    <!-- Form Pencarian dengan Card -->
    <div class="card shadow-sm mb-4">
        <div class="card-body">
            <form action="<?php echo e(route('user.view')); ?>" method="GET" class="mb-0">
                <div class="row g-3 align-items-end">
                    <div class="col-md-8">
                        <label for="search" class="form-label">Cari User</label>
                        <div class="input-group">
                            <input type="text" name="search" class="form-control" 
                                   placeholder="Masukkan nama atau email user..." 
                                   value="<?php echo e(request('search')); ?>"
                                   id="searchInput">
                            <button type="submit" class="btn btn-primary">
                                <i class="bi bi-search me-1"></i> Cari
                            </button>
                            <?php if(request('search')): ?>
                            <a href="<?php echo e(route('user.view')); ?>" class="btn btn-secondary">
                                <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
                            </a>
                            <?php endif; ?>
                        </div>
                    </div>
                </div>
            </form>
        </div>
    </div>

    <!-- Info Hasil Pencarian -->
    <?php if(request('search')): ?>
    <div class="alert alert-info mb-3">
        <i class="bi bi-info-circle"></i> Menampilkan hasil pencarian untuk: <strong>"<?php echo e(request('search')); ?>"</strong>
        <a href="<?php echo e(route('user.view')); ?>" class="float-end text-decoration-none">
            <i class="bi bi-x"></i> Hapus pencarian
        </a>
    </div>
    <?php endif; ?>

    <!-- Baris Info Jumlah Data dan Tombol Tambah -->
    <div class="d-flex justify-content-between align-items-center mb-3">
        <div class="text-muted">
            Menampilkan <?php echo e($users->firstItem() ?? 0); ?> - <?php echo e($users->lastItem() ?? 0); ?> dari <?php echo e($users->total() ?? 0); ?> user
        </div>
        <a href="<?php echo e(route('user.insert')); ?>" class="btn btn-success">
            <i class="bi bi-plus-circle me-1"></i> Tambah User
        </a>
    </div>

    <div class="table-responsive">
        <table class="table table-bordered table-hover align-middle">
            <thead class="table-dark text-center">
                <tr>
                    <th width="60">No</th>
                    <th>Nama User</th>                    
                    <th>Email</th>
                    <th>Level</th>
                    <th>Email Terverifikasi</th>
                    <th>Tanggal Dibuat</th>
                    <th>Tanggal Diupdate</th>
                    <th width="150">Aksi</th>
                </tr>
            </thead>
            <tbody>
                <?php $__empty_1 = true; $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="text-center"><?php echo e(($users->currentPage() - 1) * $users->perPage() + $loop->iteration); ?></td>
                    <td class="fw-semibold"><?php echo e($item->name); ?></td>                    
                    <td><?php echo e($item->email); ?></td>
                    <td class="fw-semibold"><?php echo e($item->level); ?></td>
                    <td class="text-center">
                        <?php if($item->email_verified_at): ?>
                            <span class="badge bg-success">Terverifikasi</span>
                        <?php else: ?>
                            <span class="badge bg-warning text-dark">Belum verifikasi</span>
                        <?php endif; ?>
                    </td>
                    <td class="text-center"><?php echo e($item->formatted_created_at); ?></td>
                    <td class="text-center"><?php echo e($item->formatted_updated_at); ?></td>
                    <td class="text-center">
                        
                        
                        <form action="<?php echo e(route('user.destroy', $item->id)); ?>" method="POST" class="d-inline">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>
                            <button type="submit" class="btn btn-danger btn-sm" 
                                    onclick="return confirm('Apakah Anda yakin ingin menghapus user ini?');" title="Hapus">
                                <i class="bi bi-trash"></i>
                            </button>
                        </form>
                    </td>
                </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="text-center py-4">
                        <?php if(request('search')): ?>
                            User dengan kata kunci "<?php echo e(request('search')); ?>" tidak ditemukan
                        <?php else: ?>
                            Tidak ada data user
                        <?php endif; ?>
                    </td>
                </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>

    <!-- Pagination -->
    <?php if($users->hasPages()): ?>
    <div class="d-flex justify-content-center mt-4">
        <?php echo e($users->withQueryString()->links()); ?>

    </div>
    <?php endif; ?>
</div>

<script>
// Auto focus ke input pencarian
document.addEventListener('DOMContentLoaded', function() {
    const searchInput = document.getElementById('searchInput');
    if (searchInput) {
        searchInput.focus();
        
        // Clear pencarian dengan tombol Esc
        searchInput.addEventListener('keyup', function(e) {
            if (e.key === 'Escape') {
                window.location.href = "<?php echo e(route('user.view')); ?>";
            }
        });
    }
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/user/view.blade.php ENDPATH**/ ?>