<!-- resources/views/dashboard/detail.blade.php -->


<?php $__env->startSection('content'); ?>
<div class="container-fluid">
    <h1>Detail Performance - <?php echo e($bulan); ?> - <?php echo e($akun->nama_akun); ?></h1>
    
    <?php if($akunDetails->count() > 0): ?>
    <div class="alert alert-info">
        Menampilkan detail untuk akun: <strong><?php echo e($akun->nama_akun); ?></strong>
    </div>
    <?php endif; ?>
    
    <div class="card">
        <div class="card-body">
            <div class="table-responsive">
                <table class="table table-bordered table-striped">
                    <thead>
                        <tr>
                            <th>Kode Akun</th>
                            <th>Nama Akun</th>
                            <th>Tanggal</th>
                            <th>Hari</th>
                            <th>Target</th>
                            <th>Realisasi</th>
                            <th>GAP</th>
                            <th>% Gap</th>
                            <th>Keterangan</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $detailData; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <?php
                            $gap = $item->realisasi - $item->target;
                            $persen_gap = $item->target > 0 ? ($gap / $item->target) * 100 : 0;
                        ?>
                        <tr>
                            <td><?php echo e($item->kd_akun); ?></td>
                            <td><?php echo e($item->nama_akun); ?></td>
                            <td><?php echo e($item->tanggal); ?></td>
                            <td><?php echo e($item->hari); ?></td>
                            <td><?php echo e(number_format($item->target, 0, ',', '.')); ?></td>
                            <td><?php echo e(number_format($item->realisasi, 0, ',', '.')); ?></td>
                            <td class="<?php echo e($gap >= 0 ? 'text-success' : 'text-danger'); ?>">
                                <?php echo e(number_format($gap, 0, ',', '.')); ?>

                            </td>
                            <td class="<?php echo e($persen_gap >= 0 ? 'text-success' : 'text-danger'); ?>">
                                <?php echo e(number_format($persen_gap, 2)); ?>%
                            </td>
                            <td><?php echo e($item->keterangan_realisasi ?: $item->keterangan_target); ?></td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    
    <a href="<?php echo e(route('dashboard.view')); ?>" class="btn btn-secondary mt-3">Kembali ke Dashboard</a>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/dashboard/detail.blade.php ENDPATH**/ ?>