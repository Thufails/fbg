
<?php $__env->startSection('title', 'Daftar Detail Realisasi'); ?>
<?php $__env->startSection('content'); ?>
<div class="container-fluid">
  <h4 class="mb-3"><i class="bi bi-check-circle"></i> Data Detail Realisasi</h4>
  <?php echo $__env->make('layouts.notif', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
  <!-- Search Form -->
  <div class="card shadow-sm mb-4">
    <div class="card-body">
      <form action="<?php echo e(route('detailRealisasi.view')); ?>" method="GET" class="mb-0">
        <div class="row g-3 align-items-end">
          <div class="col-md-2">
            <label for="start_date" class="form-label">Tanggal Awal</label>
            <input type="date" name="start_date" class="form-control" 
                   value="<?php echo e(request('start_date')); ?>" id="start_date">
          </div>
          <div class="col-md-2">
            <label for="end_date" class="form-label">Tanggal Akhir</label>
            <input type="date" name="end_date" class="form-control" 
                   value="<?php echo e(request('end_date')); ?>" id="end_date">
          </div>
          <div class="col-md-2">
            <label for="kd_detail_akun" class="form-label">Detail Akun</label>
            <select name="kd_detail_akun" class="form-select" id="kd_detail_akun">
              <option value="">Semua Detail Akun</option>
              <?php $__currentLoopData = $targetDetailList ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $targetDetail): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($targetDetail->kd_detail_akun); ?>" <?php echo e(request('kd_detail_akun') == $targetDetail->kd_detail_akun ? 'selected' : ''); ?>>
                  <?php echo e($targetDetail->nama_akun); ?> - <?php echo e($targetDetail->nama_detail_akun); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-md-2">
            <label for="kd_entitas" class="form-label">Entitas</label>
            <select name="kd_entitas" class="form-select" id="kd_entitas">
              <option value="">Semua Entitas</option>
              <?php $__currentLoopData = $entitasList ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $entitas): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($entitas->kd_entitas); ?>" <?php echo e(request('kd_entitas') == $entitas->kd_entitas ? 'selected' : ''); ?>>
                  <?php echo e($entitas->kd_entitas); ?> - <?php echo e($entitas->nama_entitas); ?>

                </option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </div>
          <div class="col-md-2">
            <button type="submit" class="btn btn-primary w-100">
              <i class="bi bi-funnel me-1"></i> Filter
            </button>
            <?php if(request('start_date') || request('end_date') || request('kd_detail_akun') || request('kd_entitas')): ?>
            <a href="<?php echo e(route('detailRealisasi.view')); ?>" class="btn btn-secondary w-100 mt-2">
              <i class="bi bi-arrow-counterclockwise me-1"></i> Reset
            </a>
            <?php endif; ?>
          </div>
        </div>
      </form>
    </div>
  </div>

  <div class="d-flex justify-content-between align-items-center mb-3">
    <div class="text-muted">
      Menampilkan <?php echo e($detailRealisasi->firstItem() ?? 0); ?> - <?php echo e($detailRealisasi->lastItem() ?? 0); ?> dari <?php echo e($detailRealisasi->total() ?? 0); ?> Realisasi
    </div>
    <div>
      <button id="bulkDeleteBtn" class="btn btn-danger me-2" disabled>
        <i class="bi bi-trash me-1"></i> Hapus yang Dipilih
      </button>
      <a href="<?php echo e(route('detailRealisasi.select')); ?>" class="btn btn-success">
        <i class="bi bi-plus-circle me-1"></i> Tambah Realisasi
      </a>
    </div>
  </div>

  <!-- Data Table -->
  <div class="table-responsive">
    <form id="bulkDeleteForm" action="<?php echo e(route('detailRealisasi.bulkDestroy')); ?>" method="POST">
      <?php echo csrf_field(); ?>
      <?php echo method_field('DELETE'); ?>
      <table class="table table-bordered table-hover align-middle">
        <thead class="table-dark text-center">
          <tr>
            <th width="50">
              <input type="checkbox" id="checkAll" class="form-check-input">
            </th>
            <th width="60">No</th>
            <th>Tanggal Masehi</th>
            <th>Tanggal Hijriah</th>
            <th>Entitas</th>
            <th>Detail Akun</th>
            <th>Nilai Realisasi</th>
            <th>Hari</th>
            <th>Bulan</th>
            <th>Tahun</th>
          </tr>
        </thead>
        <tbody>
          <?php $__empty_1 = true; $__currentLoopData = $detailRealisasi; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
          <tr>
            <td class="text-center">
              <input type="checkbox" name="selected_ids[]" value="<?php echo e($item->kd_detail_realisasi); ?>" class="form-check-input target-checkbox">
            </td>
            <td class="text-center"><?php echo e(($detailRealisasi->currentPage() - 1) * $detailRealisasi->perPage() + $loop->iteration); ?></td>
            <td><?php echo e(\Carbon\Carbon::parse($item->tanggal)->format('d-m-Y')); ?></td>
            <td class="text-center">
              <?php if(isset($item->tanggal_hijriah) && !empty($item->tanggal_hijriah)): ?>
                <?php echo e($item->tanggal_hijriah); ?>

              <?php else: ?>
                -
              <?php endif; ?>
            </td>
            <td><?php echo e($item->nama_entitas ?? '-'); ?></td>
            <td><?php echo e($item->nama_detail_akun); ?></td>
            <td class="text-end"><?php echo e(number_format($item->nilai, 0, ',', '.')); ?></td>
            <td><?php echo e($item->hari); ?></td>
            <td><?php echo e($item->bulan); ?></td>
            <td><?php echo e($item->tahun); ?></td>
          </tr>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
          <tr>
            <td colspan="10" class="text-center py-4">
              <?php if(request('start_date') || request('end_date') || request('kd_detail_akun') || request('kd_entitas')): ?>
                Tidak ditemukan realisasi dengan filter yang dipilih
              <?php else: ?>
                Tidak ada data realisasi
              <?php endif; ?>
            </td>
          </tr>
          <?php endif; ?>
        </tbody>
      </table>
    </form>
  </div>

  <!-- Pagination -->
  <?php if($detailRealisasi->hasPages()): ?>
  <div class="d-flex justify-content-center mt-4">
    <?php echo e($detailRealisasi->withQueryString()->links()); ?>

  </div>
  <?php endif; ?>
</div>

<style>
  .table {
    font-size: 0.9rem;
  }
  .table-dark {
    background-color: #212529;
  }
  .table-hover tbody tr:hover {
    background-color: rgba(0, 0, 0, 0.05);
  }
  .btn-sm {
    padding: 0.25rem 0.5rem;
    font-size: 0.75rem;
  }
  .card {
    border-radius: 0.5rem;
    border: 1px solid #dee2e6;
  }
  .text-end {
    text-align: right !important;
  }
  .form-check-input {
    cursor: pointer;
    margin: 0 auto;
    display: block;
  }
</style>

<script>
document.addEventListener('DOMContentLoaded', function() {
  const checkAll = document.getElementById('checkAll');
  const checkboxes = document.querySelectorAll('.target-checkbox');
  const bulkDeleteBtn = document.getElementById('bulkDeleteBtn');
  const bulkDeleteForm = document.getElementById('bulkDeleteForm');

  // Check All functionality
  checkAll.addEventListener('change', function() {
    const isChecked = this.checked;
    checkboxes.forEach(checkbox => {
      checkbox.checked = isChecked;
    });
    updateBulkActionButtons();
  });

  // Individual checkbox functionality
  checkboxes.forEach(checkbox => {
    checkbox.addEventListener('change', function() {
      if (!this.checked && checkAll.checked) {
        checkAll.checked = false;
      }
      const allChecked = Array.from(checkboxes).every(cb => cb.checked);
      checkAll.checked = allChecked;
      updateBulkActionButtons();
    });
  });

  function updateBulkActionButtons() {
    const checkedCount = document.querySelectorAll('.target-checkbox:checked').length;
    bulkDeleteBtn.disabled = checkedCount === 0;
    
    bulkDeleteBtn.innerHTML = checkedCount > 0 
      ? `<i class="bi bi-trash me-1"></i> Hapus (${checkedCount})` 
      : `<i class="bi bi-trash me-1"></i> Hapus yang Dipilih`;
  }

  // Bulk delete button click handler
  bulkDeleteBtn.addEventListener('click', function(e) {
    e.preventDefault();
    const checkedCount = document.querySelectorAll('.target-checkbox:checked').length;
    
    if (checkedCount > 0 && confirm(`Apakah Anda yakin ingin menghapus ${checkedCount} realisasi yang dipilih?`)) {
      // Show loading state
      bulkDeleteBtn.disabled = true;
      bulkDeleteBtn.innerHTML = `<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Menghapus...`;
      
      // Submit form
      bulkDeleteForm.submit();
    }
  });
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/detailRealisasi/view.blade.php ENDPATH**/ ?>