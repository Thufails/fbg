
<?php $__env->startSection('content'); ?>
<div class="container">
  <h3 class="mb-4"><i class="bi bi-pencil-square text-primary"></i> Edit Komplain</h3>
  <form action="<?php echo e(route('komplain.update', $komplain->kd_komplain)); ?>" method="POST">
    <?php echo csrf_field(); ?>
    <?php echo method_field('PUT'); ?>
    <div class="row g-3">
      <!-- Tanggal Komplain -->
      <div class="col-md-6">
        <label class="form-label"><i class="bi bi-calendar-date text-primary"></i> Tanggal</label>
        <input type="date" name="tanggal" class="form-control" value="<?php echo e(old('tanggal', $komplain->tanggal)); ?>" required>
      </div>

      <!-- Sumber Komplain -->
      <div class="col-md-6">
        <label class="form-label"><i class="bi bi-source text-primary"></i> Sumber</label>
        <select class="form-select" name="sumber" required>
          <option value="" disabled>Pilih Sumber</option>
          <option value="Pelanggan" <?php echo e(old('sumber', $komplain->sumber) == 'Pelanggan' ? 'selected' : ''); ?>>Pelanggan</option>
          <option value="Internal" <?php echo e(old('sumber', $komplain->sumber) == 'Internal' ? 'selected' : ''); ?>>Internal</option>
          <option value="Pemasok" <?php echo e(old('sumber', $komplain->sumber) == 'Pemasok' ? 'selected' : ''); ?>>Pemasok</option>
          <option value="Lainnya" <?php echo e(old('sumber', $komplain->sumber) == 'Lainnya' ? 'selected' : ''); ?>>Lainnya</option>
        </select>
      </div>

      <!-- Kategori Komplain -->
      <div class="col-md-6">
        <label class="form-label"><i class="bi bi-tag text-primary"></i> Kategori</label>
        <select class="form-select" name="kategori" required>
          <option value="" disabled>Pilih Kategori</option>
          <option value="Produk" <?php echo e(old('kategori', $komplain->kategori) == 'Produk' ? 'selected' : ''); ?>>Produk</option>
          <option value="Layanan" <?php echo e(old('kategori', $komplain->kategori) == 'Layanan' ? 'selected' : ''); ?>>Layanan</option>
          <option value="Teknis" <?php echo e(old('kategori', $komplain->kategori) == 'Teknis' ? 'selected' : ''); ?>>Teknis</option>
          <option value="Administrasi" <?php echo e(old('kategori', $komplain->kategori) == 'Administrasi' ? 'selected' : ''); ?>>Administrasi</option>
        </select>
      </div>

      <!-- Prioritas -->
      <div class="col-md-6">
        <label class="form-label"><i class="bi bi-exclamation-triangle text-primary"></i> Prioritas</label>
        <div class="form-radio-group">
          <div class="form-radio-item">
            <input class="form-check-input" type="radio" name="prioritas" id="prioritas-rendah" value="rendah" <?php echo e(old('prioritas', $komplain->prioritas) == 'rendah' ? 'checked' : ''); ?>>
            <label class="form-check-label ms-2 text-success" for="prioritas-rendah">
              Rendah
            </label>
          </div>
          <div class="form-radio-item">
            <input class="form-check-input" type="radio" name="prioritas" id="prioritas-sedang" value="sedang" <?php echo e(old('prioritas', $komplain->prioritas) == 'sedang' ? 'checked' : ''); ?>>
            <label class="form-check-label ms-2 text-warning" for="prioritas-sedang">
              Sedang
            </label>
          </div>
          <div class="form-radio-item">
            <input class="form-check-input" type="radio" name="prioritas" id="prioritas-tinggi" value="tinggi" <?php echo e(old('prioritas', $komplain->prioritas) == 'tinggi' ? 'checked' : ''); ?>>
            <label class="form-check-label ms-2 text-danger" for="prioritas-tinggi">
              Tinggi
            </label>
          </div>
        </div>
      </div>

      <!-- Deskripsi Komplain -->
      <div class="col-12">
        <label class="form-label"><i class="bi bi-chat-left-text text-primary"></i> Deskripsi Komplain</label>
        <textarea name="uraian" class="form-control" rows="4" required><?php echo e(old('uraian', $komplain->uraian)); ?></textarea>
      </div>

      <!-- Status -->
      <div class="col-12">
        <label class="form-label"><i class="bi bi-clipboard-check text-primary"></i> Status</label>
        <div class="form-radio-group">
          <div class="form-radio-item">
            <input class="form-check-input" type="radio" name="status" id="status-baru" value="0" <?php echo e(old('status', $komplain->status) == 0 ? 'checked' : ''); ?>>
            <label class="form-check-label ms-2" for="status-baru">
              <i class="bi bi-file-earmark-plus text-info"></i> Baru
            </label>
          </div>
          <div class="form-radio-item">
            <input class="form-check-input" type="radio" name="status" id="status-proses" value="1" <?php echo e(old('status', $komplain->status) == 1 ? 'checked' : ''); ?>>
            <label class="form-check-label ms-2" for="status-proses">
              <i class="bi bi-gear text-warning"></i> Proses
            </label>
          </div>
          <div class="form-radio-item">
            <input class="form-check-input" type="radio" name="status" id="status-selesai" value="2" <?php echo e(old('status', $komplain->status) == 2 ? 'checked' : ''); ?>>
            <label class="form-check-label ms-2" for="status-selesai">
              <i class="bi bi-check-circle text-success"></i> Selesai
            </label>
          </div>
        </div>
      </div>

      <!-- Tombol Aksi -->
      <div class="col-12 d-flex justify-content-between mt-4">
        <a href="<?php echo e(route('komplain.view')); ?>" class="btn btn-outline-secondary">
          <i class="bi bi-arrow-left-circle"></i> Kembali
        </a>
        <div>
          <button type="submit" class="btn btn-primary me-2">
            <i class="bi bi-check-circle"></i> Simpan Perubahan
          </button>
          <a href="<?php echo e(route('komplain.detail', $komplain->kd_komplain)); ?>" class="btn btn-info">
            <i class="bi bi-eye"></i> Lihat Detail
          </a>
        </div>
      </div>
    </div>
  </form>
</div>

<style>
  .form-radio-group {
    display: flex;
    gap: 1.5rem;
  }
  .form-radio-item {
    display: flex;
    align-items: center;
  }
</style>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.appform', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /home/binsysid/sbs.binsys.id/resources/views/komplain/edit.blade.php ENDPATH**/ ?>